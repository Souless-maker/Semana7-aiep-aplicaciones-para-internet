<?php
// ARCHIVO TEMPORAL: debug.php - Colocar en la raíz del proyecto

// Conectar a la base de datos
$host = 'localhost';
$dbname = 'el_faro_db';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<h1>🔍 DEBUG: Estado de Artículos en El Faro</h1>";
    echo "<style>body{font-family:Arial;} .box{border:1px solid #ddd;padding:10px;margin:10px 0;} .ok{background:#d4edda;} .error{background:#f8d7da;}</style>";
    
    // 1. Verificar conexión
    echo "<div class='box ok'><h3>✅ Conexión a base de datos: OK</h3></div>";
    
    // 2. Contar artículos totales
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM articulos");
    $total = $stmt->fetch()['total'];
    echo "<div class='box'><h3>📊 Total artículos en BD: $total</h3></div>";
    
    // 3. Contar por estado
    $stmt = $pdo->query("SELECT activo, COUNT(*) as cantidad FROM articulos GROUP BY activo");
    echo "<div class='box'><h3>📈 Artículos por estado:</h3>";
    while ($row = $stmt->fetch()) {
        $estado = $row['activo'] ? 'Publicados' : 'Borradores';
        echo "- $estado: {$row['cantidad']}<br>";
    }
    echo "</div>";
    
    // 4. Últimos 5 artículos
    $stmt = $pdo->query("SELECT id, titulo, activo, fecha_publicacion FROM articulos ORDER BY fecha_publicacion DESC LIMIT 5");
    echo "<div class='box'><h3>📰 Últimos 5 artículos:</h3>";
    while ($row = $stmt->fetch()) {
        $estado = $row['activo'] ? '✅ Publicado' : '📝 Borrador';
        echo "ID {$row['id']}: {$row['titulo']} - $estado - {$row['fecha_publicacion']}<br>";
    }
    echo "</div>";
    
    // 5. Consulta que usa el frontend
    $stmt = $pdo->query("
        SELECT a.*, c.nombre as categoria_nombre, u.nombre as autor_nombre 
        FROM articulos a 
        LEFT JOIN categorias c ON c.id = a.categoria_id 
        LEFT JOIN usuarios u ON u.id = a.usuario_id 
        WHERE a.activo = 1 
        ORDER BY a.fecha_publicacion DESC 
        LIMIT 6
    ");
    $publicados = $stmt->fetchAll();
    
    if (count($publicados) > 0) {
        echo "<div class='box ok'><h3>✅ Artículos que debería mostrar el frontend:</h3>";
        foreach ($publicados as $art) {
            echo "- {$art['titulo']} (Categoría: {$art['categoria_nombre']})<br>";
        }
        echo "</div>";
    } else {
        echo "<div class='box error'><h3>❌ PROBLEMA: No hay artículos publicados (activo=1)</h3>";
        echo "Solución: Cambiar artículos a activo=1 o verificar por qué se guardan como 0</div>";
    }
    
    // 6. Verificar si hay artículos recientes pero no activos
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM articulos WHERE activo = 0 AND fecha_publicacion >= DATE_SUB(NOW(), INTERVAL 1 DAY)");
    $borradores_recientes = $stmt->fetch()['total'];
    
    if ($borradores_recientes > 0) {
        echo "<div class='box error'><h3>⚠️ ENCONTRADO: $borradores_recientes artículos recientes como BORRADOR</h3>";
        echo "Posible causa: El formulario los guarda como activo=0 en lugar de activo=1</div>";
    }
    
    echo "<hr><p><strong>💡 Diagnóstico completado.</strong> Si no hay artículos publicados (activo=1), ese es el problema.</p>";
    echo "<p><strong>🔧 Solución rápida:</strong> UPDATE articulos SET activo = 1 WHERE activo = 0;</p>";
    
} catch (PDOException $e) {
    echo "<div class='box error'><h3>❌ Error de conexión:</h3>" . $e->getMessage() . "</div>";
}
?>