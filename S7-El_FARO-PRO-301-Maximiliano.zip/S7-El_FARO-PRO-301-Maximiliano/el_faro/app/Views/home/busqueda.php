<!-- Breadcrumb -->
<div class="container mt-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('/') ?>">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Búsqueda</li>
        </ol>
    </nav>
</div>

<!-- Search Header -->
<div class="container">
    <div class="row mb-4">
        <div class="col-12">
            <div class="bg-light p-4 rounded">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h1 class="mb-2">
                            <i class="fas fa-search me-2"></i>
                            Resultados de búsqueda para: "<strong><?= esc($termino) ?></strong>"
                        </h1>
                        <p class="mb-0 text-muted">
                            Se encontraron <strong><?= count($articulos) ?></strong> resultado(s)
                            <?php if (isset($_GET['categoria'])): ?>
                                en la sección seleccionada
                            <?php endif; ?>
                        </p>
                    </div>
                    <div class="col-md-4">
                        <!-- Search refinement form -->
                        <form method="GET" action="<?= base_url('/buscar') ?>" class="d-flex">
                            <input type="text" name="q" class="form-control me-2" value="<?= esc($termino) ?>" placeholder="Refinar búsqueda...">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-search"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Search Results -->
<div class="container">
    <div class="row">
        <!-- Main Results -->
        <div class="col-lg-8">
            <?php if (!empty($articulos)): ?>
                <!-- Sort Options -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <small class="text-muted">Ordenar por:</small>
                        <div class="btn-group btn-group-sm ms-2" role="group">
                            <button type="button" class="btn btn-outline-primary active" data-sort="relevancia">
                                <i class="fas fa-star me-1"></i>Relevancia
                            </button>
                            <button type="button" class="btn btn-outline-primary" data-sort="fecha">
                                <i class="fas fa-calendar me-1"></i>Fecha
                            </button>
                            <button type="button" class="btn btn-outline-primary" data-sort="categoria">
                                <i class="fas fa-tag me-1"></i>Categoría
                            </button>
                        </div>
                    </div>
                    <div>
                        <small class="text-muted">
                            Mostrando <?= count($articulos) ?> de <?= count($articulos) ?> resultados
                        </small>
                    </div>
                </div>
                
                <!-- Search Results List -->
                <div id="search-results">
                    <?php foreach ($articulos as $index => $articulo): ?>
                        <div class="card mb-4 search-result-item" data-fecha="<?= strtotime($articulo['fecha_publicacion']) ?>" data-categoria="<?= esc($articulo['categoria_nombre']) ?>">
                            <div class="row g-0">
                                <div class="col-md-4">
                                    <?php if (!empty($articulo['imagen'])): ?>
                                        <img src="<?= base_url('uploads/' . $articulo['imagen']) ?>" class="img-fluid rounded-start h-100" alt="<?= esc($articulo['titulo']) ?>" style="object-fit: cover;">
                                    <?php else: ?>
                                        <div class="bg-light d-flex align-items-center justify-content-center h-100 rounded-start">
                                            <i class="fas fa-newspaper fa-3x text-muted"></i>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                            <span class="badge bg-primary"><?= esc($articulo['categoria_nombre']) ?></span>
                                            <small class="text-muted">
                                                <i class="fas fa-calendar me-1"></i>
                                                <?= date('d/m/Y', strtotime($articulo['fecha_publicacion'])) ?>
                                            </small>
                                        </div>
                                        
                                        <h5 class="card-title">
                                            <a href="<?= base_url('/articulo/' . $articulo['id']) ?>" class="text-decoration-none">
                                                <?= esc($articulo['titulo']) ?>
                                            </a>
                                        </h5>
                                        
                                        <?php if (!empty($articulo['resumen'])): ?>
                                            <p class="card-text"><?= esc($articulo['resumen']) ?></p>
                                        <?php else: ?>
                                            <p class="card-text"><?= esc(substr(strip_tags($articulo['contenido']), 0, 150)) ?>...</p>
                                        <?php endif; ?>
                                        
                                        <div class="d-flex justify-content-between align-items-center">
                                            <a href="<?= base_url('/articulo/' . $articulo['id']) ?>" class="btn btn-primary btn-sm">
                                                Leer completo <i class="fas fa-arrow-right ms-1"></i>
                                            </a>
                                            
                                            <div class="btn-group btn-group-sm">
                                                <button class="btn btn-outline-secondary" onclick="shareArticle('<?= $articulo['id'] ?>')">
                                                    <i class="fas fa-share"></i>
                                                </button>
                                                <button class="btn btn-outline-secondary" onclick="saveForLater('<?= $articulo['id'] ?>')">
                                                    <i class="fas fa-bookmark"></i>
                                                </button>
                                            </div>
                                        </div>
                                        
                                        <?php if (!empty($articulo['autor_nombre'])): ?>
                                            <small class="text-muted d-block mt-2">
                                                <i class="fas fa-user me-1"></i>
                                                Por <?= esc($articulo['autor_nombre']) ?>
                                            </small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Pagination (if needed) -->
                <?php if (count($articulos) >= 20): ?>
                    <div class="text-center mt-4">
                        <nav aria-label="Paginación de resultados">
                            <ul class="pagination justify-content-center">
                                <li class="page-item disabled">
                                    <span class="page-link">Anterior</span>
                                </li>
                                <li class="page-item active">
                                    <span class="page-link">1</span>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#">2</a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#">3</a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#">Siguiente</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                <?php endif; ?>
                
                <!-- Load more button -->
                <div class="text-center mt-4" id="load-more-container" style="display: none;">
                    <button class="btn btn-outline-primary btn-lg" id="load-more-btn">
                        <i class="fas fa-plus me-2"></i>Cargar más resultados
                    </button>
                </div>
                
            <?php else: ?>
                <!-- No Results Found -->
                <div class="text-center py-5">
                    <i class="fas fa-search fa-4x text-muted mb-3"></i>
                    <h3>No se encontraron resultados</h3>
                    <p class="text-muted mb-4">
                        No encontramos artículos que coincidan con "<strong><?= esc($termino) ?></strong>"
                    </p>
                    
                    <!-- Suggestions -->
                    <div class="card bg-light">
                        <div class="card-body">
                            <h5>Sugerencias:</h5>
                            <ul class="list-unstyled mb-0">
                                <li><i class="fas fa-check text-success me-2"></i>Verifica la ortografía de las palabras</li>
                                <li><i class="fas fa-check text-success me-2"></i>Intenta con términos más generales</li>
                                <li><i class="fas fa-check text-success me-2"></i>Usa sinónimos o palabras relacionadas</li>
                                <li><i class="fas fa-check text-success me-2"></i>Reduce el número de palabras en la búsqueda</li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="mt-4">
                        <a href="<?= base_url('/') ?>" class="btn btn-primary me-2">
                            <i class="fas fa-home me-2"></i>Volver al Inicio
                        </a>
                        <a href="#" class="btn btn-outline-primary" onclick="showPopularSearches()">
                            <i class="fas fa-fire me-2"></i>Búsquedas populares
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Search Sidebar -->
        <div class="col-lg-4">
            <!-- Advanced Search -->
            <div class="sidebar-widget">
                <h4 class="widget-title"><i class="fas fa-filter me-2"></i>Filtrar Resultados</h4>
                <form method="GET" action="<?= base_url('/buscar') ?>" id="advanced-search">
                    <input type="hidden" name="q" value="<?= esc($termino) ?>">
                    
                    <div class="mb-3">
                        <label class="form-label">Categoría:</label>
                        <select class="form-select" name="categoria">
                            <option value="">Todas las categorías</option>
                            <?php if (!empty($categorias)): ?>
                                <?php foreach ($categorias as $categoria): ?>
                                    <option value="<?= $categoria['id'] ?>" <?= (isset($_GET['categoria']) && $_GET['categoria'] == $categoria['id']) ? 'selected' : '' ?>>
                                        <?= esc($categoria['nombre']) ?>
                                    </option>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Fecha:</label>
                        <select class="form-select" name="fecha">
                            <option value="">Cualquier fecha</option>
                            <option value="hoy">Hoy</option>
                            <option value="semana">Esta semana</option>
                            <option value="mes">Este mes</option>
                            <option value="año">Este año</option>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-2"></i>Aplicar Filtros
                    </button>
                </form>
            </div>
            
            <!-- Popular Searches -->
            <div class="sidebar-widget">
                <h4 class="widget-title"><i class="fas fa-fire me-2"></i>Búsquedas Populares</h4>
                <div class="popular-searches">
                    <a href="<?= base_url('/buscar?q=deportes') ?>" class="badge bg-light text-dark me-2 mb-2">deportes</a>
                    <a href="<?= base_url('/buscar?q=cultura') ?>" class="badge bg-light text-dark me-2 mb-2">cultura</a>
                    <a href="<?= base_url('/buscar?q=economia') ?>" class="badge bg-light text-dark me-2 mb-2">economía</a>
                    <a href="<?= base_url('/buscar?q=noticias') ?>" class="badge bg-light text-dark me-2 mb-2">noticias</a>
                    <a href="<?= base_url('/buscar?q=comunidad') ?>" class="badge bg-light text-dark me-2 mb-2">comunidad</a>
                    <a href="<?= base_url('/buscar?q=eventos') ?>" class="badge bg-light text-dark me-2 mb-2">eventos</a>
                </div>
            </div>
            
            <!-- Categories Widget -->
            <div class="sidebar-widget">
                <h4 class="widget-title"><i class="fas fa-list me-2"></i>Explorar por Categorías</h4>
                <?php if (!empty($categorias)): ?>
                    <?php foreach ($categorias as $categoria): ?>
                        <a href="<?= base_url('/seccion/' . $categoria['slug']) ?>" class="category-link">
                            <i class="fas fa-chevron-right me-2"></i>
                            <?= esc($categoria['nombre']) ?>
                        </a>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <!-- Search Tips -->
            <div class="sidebar-widget">
                <h4 class="widget-title"><i class="fas fa-lightbulb me-2"></i>Consejos de Búsqueda</h4>
                <div class="search-tips">
                    <div class="tip-item mb-3">
                        <strong>Usa comillas</strong> para buscar frases exactas
                        <br><small class="text-muted">Ejemplo: "nueva biblioteca"</small>
                    </div>
                    <div class="tip-item mb-3">
                        <strong>Combina palabras clave</strong> relacionadas
                        <br><small class="text-muted">Ejemplo: deporte fútbol torneo</small>
                    </div>
                    <div class="tip-item">
                        <strong>Usa filtros</strong> para refinar resultados
                        <br><small class="text-muted">Filtra por categoría o fecha</small>
                    </div>
                </div>
            </div>
            
            <!-- Newsletter -->
            <div class="sidebar-widget">
                <h4 class="widget-title"><i class="fas fa-envelope me-2"></i>Recibe las últimas noticias</h4>
                <p class="small">Mantente informado con nuestro newsletter semanal.</p>
                <form id="newsletter-search">
                    <div class="mb-3">
                        <input type="email" class="form-control" placeholder="Tu email" required>
                    </div>
                    <button type="submit" class="btn btn-success w-100">
                        <i class="fas fa-paper-plane me-2"></i>Suscribirse
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Sort functionality
    $('[data-sort]').on('click', function() {
        const sortType = $(this).data('sort');
        $('[data-sort]').removeClass('active');
        $(this).addClass('active');
        
        let $results = $('.search-result-item');
        let sortedResults;
        
        switch(sortType) {
            case 'fecha':
                sortedResults = $results.sort(function(a, b) {
                    return $(b).data('fecha') - $(a).data('fecha');
                });
                break;
            case 'categoria':
                sortedResults = $results.sort(function(a, b) {
                    return $(a).data('categoria').localeCompare($(b).data('categoria'));
                });
                break;
            default: // relevancia
                sortedResults = $results.sort(function(a, b) {
                    return $(a).index() - $(b).index();
                });
        }
        
        $('#search-results').html(sortedResults);
    });
    
    // Newsletter form
    $('#newsletter-search').on('submit', function(e) {
        e.preventDefault();
        const email = $(this).find('input[type="email"]').val();
        alert('¡Gracias por suscribirte! Te mantendremos informado.');
        $(this)[0].reset();
    });
    
    // Advanced search form
    $('#advanced-search').on('change', 'select', function() {
        // Auto-submit when filters change
        // $(this).closest('form').submit();
    });
});

// Share article function
function shareArticle(articleId) {
    const url = `<?= base_url('/articulo/') ?>${articleId}`;
    if (navigator.share) {
        navigator.share({
            title: 'Artículo de El Faro',
            url: url
        });
    } else {
        navigator.clipboard.writeText(url).then(function() {
            alert('Enlace copiado al portapapeles');
        });
    }
}

// Save for later function
function saveForLater(articleId) {
    alert('Artículo guardado para leer después (función por implementar)');
}

// Show popular searches
function showPopularSearches() {
    const searches = ['deportes', 'cultura', 'economía', 'noticias', 'eventos'];
    const randomSearch = searches[Math.floor(Math.random() * searches.length)];
    window.location.href = `<?= base_url('/buscar?q=') ?>${randomSearch}`;
}
</script>