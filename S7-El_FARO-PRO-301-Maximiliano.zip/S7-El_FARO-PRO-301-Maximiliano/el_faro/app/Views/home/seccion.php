<!-- Breadcrumb -->
<div class="container mt-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('/') ?>">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= esc($categoria['nombre']) ?></li>
        </ol>
    </nav>
</div>

<!-- Section Header -->
<div class="container">
    <div class="row mb-4">
        <div class="col-12">
            <div class="bg-primary text-white p-4 rounded">
                <h1 class="mb-2"><?= esc($categoria['nombre']) ?></h1>
                <?php if (!empty($categoria['descripcion'])): ?>
                    <p class="mb-0 lead"><?= esc($categoria['descripcion']) ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Articles Section -->
<div class="container">
    <div class="row">
        <!-- Main Content -->
        <div class="col-lg-8">
            <?php if (!empty($articulos)): ?>
                <div class="row">
                    <?php foreach ($articulos as $articulo): ?>
                        <div class="col-md-6 mb-4">
                            <article class="card h-100">
                                <?php if (!empty($articulo['imagen'])): ?>
                                    <img src="<?= base_url('uploads/' . $articulo['imagen']) ?>" class="card-img-top" alt="<?= esc($articulo['titulo']) ?>">
                                <?php else: ?>
                                    <div class="card-img-top bg-light d-flex align-items-center justify-content-center">
                                        <i class="fas fa-newspaper fa-3x text-muted"></i>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="card-body d-flex flex-column">
                                    <div class="article-meta mb-2">
                                        <small class="text-muted">
                                            <i class="fas fa-calendar me-1"></i>
                                            <?= date('d/m/Y H:i', strtotime($articulo['fecha_publicacion'])) ?>
                                        </small>
                                        <?php if (!empty($articulo['autor_nombre'])): ?>
                                            <small class="text-muted ms-3">
                                                <i class="fas fa-user me-1"></i>
                                                <?= esc($articulo['autor_nombre']) ?>
                                            </small>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <h5 class="card-title"><?= esc($articulo['titulo']) ?></h5>
                                    
                                    <?php if (!empty($articulo['resumen'])): ?>
                                        <p class="card-text"><?= esc($articulo['resumen']) ?></p>
                                    <?php else: ?>
                                        <p class="card-text"><?= esc(substr(strip_tags($articulo['contenido']), 0, 150)) ?>...</p>
                                    <?php endif; ?>
                                    
                                    <div class="mt-auto">
                                        <a href="<?= base_url('/articulo/' . $articulo['id']) ?>" class="btn btn-primary">
                                            Leer completo <i class="fas fa-arrow-right ms-1"></i>
                                        </a>
                                    </div>
                                </div>
                            </article>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Pagination placeholder -->
                <?php if (count($articulos) >= 10): ?>
                    <div class="text-center mt-4">
                        <nav aria-label="Paginación">
                            <ul class="pagination justify-content-center">
                                <li class="page-item disabled">
                                    <span class="page-link">Anterior</span>
                                </li>
                                <li class="page-item active">
                                    <span class="page-link">1</span>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#">2</a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#">3</a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#">Siguiente</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="fas fa-inbox fa-4x text-muted mb-3"></i>
                    <h3>No hay artículos en esta sección</h3>
                    <p class="text-muted">Pronto tendremos contenido disponible en <?= esc($categoria['nombre']) ?>.</p>
                    <a href="<?= base_url('/') ?>" class="btn btn-primary">
                        <i class="fas fa-arrow-left me-2"></i>Volver al Inicio
                    </a>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Sidebar -->
        <div class="col-lg-4">
            <!-- Estadísticas de la sección -->
            <div class="sidebar-widget">
                <h4 class="widget-title">
                    <i class="fas fa-chart-bar me-2"></i>Estadísticas
                </h4>
                <div class="stats-item mb-3">
                    <div class="d-flex justify-content-between">
                        <span>Artículos totales:</span>
                        <span class="badge bg-primary"><?= count($articulos) ?></span>
                    </div>
                </div>
                <div class="stats-item mb-3">
                    <div class="d-flex justify-content-between">
                        <span>Categoría:</span>
                        <span class="text-muted"><?= esc($categoria['nombre']) ?></span>
                    </div>
                </div>
            </div>
            
            <!-- Otras Secciones -->
            <div class="sidebar-widget">
                <h4 class="widget-title">
                    <i class="fas fa-list me-2"></i>Otras Secciones
                </h4>
                <?php if (!empty($categorias)): ?>
                    <?php foreach ($categorias as $cat): ?>
                        <?php if ($cat['id'] !== $categoria['id']): ?>
                            <a href="<?= base_url('/seccion/' . $cat['slug']) ?>" class="category-link">
                                <i class="fas fa-chevron-right me-2"></i>
                                <?= esc($cat['nombre']) ?>
                                <?php if (!empty($cat['descripcion'])): ?>
                                    <small class="d-block text-muted mt-1"><?= esc(substr($cat['descripcion'], 0, 80)) ?>...</small>
                                <?php endif; ?>
                            </a>
                        <?php endif; ?>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <!-- Widget de búsqueda en sección -->
            <div class="sidebar-widget">
                <h4 class="widget-title">
                    <i class="fas fa-search me-2"></i>Buscar en <?= esc($categoria['nombre']) ?>
                </h4>
                <form method="GET" action="<?= base_url('/buscar') ?>">
                    <div class="input-group mb-3">
                        <input type="text" name="q" class="form-control" placeholder="Buscar en esta sección..." aria-label="Buscar">
                        <input type="hidden" name="categoria" value="<?= $categoria['id'] ?>">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </form>
                <small class="text-muted">
                    <i class="fas fa-info-circle me-1"></i>
                    Busca específicamente en artículos de <?= esc($categoria['nombre']) ?>
                </small>
            </div>
            
            <!-- Newsletter específico para la sección -->
            <div class="sidebar-widget">
                <h4 class="widget-title">
                    <i class="fas fa-bell me-2"></i>Alertas de <?= esc($categoria['nombre']) ?>
                </h4>
                <p class="small">Recibe notificaciones cuando publiquemos nuevos artículos en esta sección.</p>
                <form id="seccion-alerts-form">
                    <div class="mb-3">
                        <input type="email" class="form-control" placeholder="Tu email" required>
                        <input type="hidden" value="<?= $categoria['id'] ?>" name="categoria_id">
                    </div>
                    <button type="submit" class="btn btn-outline-primary w-100">
                        <i class="fas fa-bell me-1"></i>Activar Alertas
                    </button>
                </form>
            </div>
            
            <!-- Compartir sección -->
            <div class="sidebar-widget">
                <h4 class="widget-title">
                    <i class="fas fa-share me-2"></i>Compartir Sección
                </h4>
                <div class="d-flex gap-2 justify-content-center">
                    <a href="#" class="btn btn-outline-primary btn-sm" onclick="shareSection('facebook')">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a href="#" class="btn btn-outline-info btn-sm" onclick="shareSection('twitter')">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="#" class="btn btn-outline-success btn-sm" onclick="shareSection('whatsapp')">
                        <i class="fab fa-whatsapp"></i>
                    </a>
                    <button class="btn btn-outline-secondary btn-sm" onclick="copyLink()">
                        <i class="fas fa-link"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Form de alertas por sección
    $('#seccion-alerts-form').on('submit', function(e) {
        e.preventDefault();
        const email = $(this).find('input[type="email"]').val();
        const categoriaId = $(this).find('input[name="categoria_id"]').val();
        
        // Aquí se implementaría la lógica de suscripción
        alert('¡Te has suscrito a las alertas de <?= esc($categoria['nombre']) ?>! Te notificaremos de nuevos artículos.');
        $(this)[0].reset();
    });
});

// Funciones de compartir
function shareSection(platform) {
    const url = encodeURIComponent(window.location.href);
    const title = encodeURIComponent('<?= addslashes($categoria['nombre']) ?> - El Faro');
    
    switch(platform) {
        case 'facebook':
            window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}`, '_blank');
            break;
        case 'twitter':
            window.open(`https://twitter.com/intent/tweet?url=${url}&text=${title}`, '_blank');
            break;
        case 'whatsapp':
            window.open(`https://wa.me/?text=${title} ${url}`, '_blank');
            break;
    }
}

function copyLink() {
    navigator.clipboard.writeText(window.location.href).then(function() {
        // Mostrar mensaje de confirmación
        const btn = event.target;
        const originalHTML = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-check"></i>';
        btn.classList.add('btn-success');
        btn.classList.remove('btn-outline-secondary');
        
        setTimeout(function() {
            btn.innerHTML = originalHTML;
            btn.classList.remove('btn-success');
            btn.classList.add('btn-outline-secondary');
        }, 2000);
    }).catch(function(err) {
        alert('No se pudo copiar el enlace. Inténtalo manualmente.');
    });
}

// Smooth scrolling para navegación interna
$('a[href^="#"]').on('click', function(e) {
    e.preventDefault();
    const target = $(this.getAttribute('href'));
    if (target.length) {
        $('html, body').animate({
            scrollTop: target.offset().top - 100
        }, 500);
    }
});
</script>