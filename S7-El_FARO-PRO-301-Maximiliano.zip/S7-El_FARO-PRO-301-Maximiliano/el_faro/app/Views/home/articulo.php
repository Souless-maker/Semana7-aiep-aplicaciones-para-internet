<!-- Vista de un artículo -->
<div class="container mt-4">
    <h1><?= esc($articulo['titulo']) ?></h1>
    <p><strong>Categoría:</strong> <?= esc($articulo['categoria_nombre']) ?> | <strong>Autor:</strong> <?= esc($articulo['autor_nombre']) ?></p>
    <img src="<?= base_url('uploads/' . $articulo['imagen']) ?>" class="img-fluid" alt="Imagen del artículo">
    <hr>
    <p><?= esc($articulo['contenido']) ?></p>
    <a href="<?= base_url('/') ?>" class="btn btn-primary">Volver al inicio</a>
</div>