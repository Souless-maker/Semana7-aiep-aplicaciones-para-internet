<!-- Breadcrumb -->
<div class="container mt-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('/') ?>">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Registro</li>
        </ol>
    </nav>
</div>

<!-- Registration Form -->
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-7 col-lg-6">
            <div class="card">
                <div class="card-body p-5">
                    <div class="text-center mb-4">
                        <i class="fas fa-user-plus fa-3x text-primary mb-3"></i>
                        <h2>Crear Cuenta</h2>
                        <p class="text-muted">Únete a la comunidad de El Faro</p>
                    </div>
                    
                    <div id="mensaje-registro" style="display: none;"></div>
                    
                    <form id="registro-form">
                        <div class="mb-3">
                            <label for="nombre" class="form-label">Nombre completo</label>
                            <input type="text" class="form-control" id="nombre" name="nombre" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="password" class="form-label">Contraseña</label>
                                    <input type="password" class="form-control" id="password" name="password" required>
                                    <small class="text-muted">Mínimo 6 caracteres</small>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="confirmar_password" class="form-label">Confirmar contraseña</label>
                                    <input type="password" class="form-control" id="confirmar_password" name="confirmar_password" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="terminos" required>
                            <label class="form-check-label" for="terminos">
                                Acepto los términos y condiciones
                            </label>
                        </div>
                        
                        <button type="submit" class="btn btn-primary btn-lg w-100 mb-3">
                            <i class="fas fa-user-plus me-2"></i>Crear Cuenta
                        </button>
                    </form>
                    
                    <div class="text-center">
                        <p class="mb-0">¿Ya tienes una cuenta? 
                            <a href="<?= base_url('/usuario/login') ?>" class="text-primary">Inicia sesión aquí</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#registro-form').on('submit', function(e) {
        e.preventDefault();
        
        const $form = $(this);
        const $btn = $form.find('button[type="submit"]');
        const $resultado = $('#mensaje-registro');
        
        // Validar contraseñas
        const password = $('#password').val();
        const confirmarPassword = $('#confirmar_password').val();
        
        if (password !== confirmarPassword) {
            $resultado.html(`
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Las contraseñas no coinciden.
                </div>
            `).show();
            return;
        }
        
        $btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Creando cuenta...');
        
        $.ajax({
            url: '<?= base_url('/usuario/crearCuenta') ?>',
            type: 'POST',
            data: $form.serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    $resultado.html(`
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle me-2"></i>
                            ${response.message}
                        </div>
                    `).show();
                    
                    setTimeout(function() {
                        window.location.href = '<?= base_url('/usuario/login') ?>';
                    }, 2000);
                } else {
                    let errorHtml = '<div class="alert alert-danger">';
                    errorHtml += '<i class="fas fa-exclamation-triangle me-2"></i>';
                    
                    if (response.errors) {
                        errorHtml += '<ul class="mb-0">';
                        $.each(response.errors, function(field, error) {
                            errorHtml += `<li>${error}</li>`;
                        });
                        errorHtml += '</ul>';
                    } else {
                        errorHtml += response.message;
                    }
                    
                    errorHtml += '</div>';
                    $resultado.html(errorHtml).show();
                }
            },
            error: function() {
                $resultado.html(`
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Error de conexión. Inténtalo nuevamente.
                    </div>
                `).show();
            },
            complete: function() {
                $btn.prop('disabled', false).html('<i class="fas fa-user-plus me-2"></i>Crear Cuenta');
            }
        });
    });
    
    // Validación en tiempo real de contraseñas
    $('#confirmar_password').on('keyup', function() {
        const password = $('#password').val();
        const confirmar = $(this).val();
        
        if (confirmar && password !== confirmar) {
            $(this).addClass('is-invalid');
        } else {
            $(this).removeClass('is-invalid');
        }
    });
});
</script>