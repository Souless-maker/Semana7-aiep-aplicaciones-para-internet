<!-- Breadcrumb -->
<div class="container mt-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('/') ?>">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Contacto</li>
        </ol>
    </nav>
</div>

<!-- Contact Header -->
<div class="container">
    <div class="row mb-4">
        <div class="col-12">
            <div class="bg-primary text-white p-4 rounded">
                <h1 class="mb-2"><i class="fas fa-envelope me-2"></i>Contáctanos</h1>
                <p class="mb-0 lead">¿Tienes una noticia importante? ¿Quieres colaborar con nosotros? ¡Nos encantaría escucharte!</p>
            </div>
        </div>
    </div>
</div>

<!-- Contact Content -->
<div class="container">
    <div class="row">
        <!-- Contact Form -->
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0"><i class="fas fa-paper-plane me-2"></i>Envíanos un mensaje</h4>
                </div>
                <div class="card-body">
                    <div id="mensaje-contacto" style="display: none;"></div>
                    
                    <form id="contacto-form">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="nombre" class="form-label">Nombre completo *</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                                        <input type="text" class="form-control" id="nombre" name="nombre" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email *</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                        <input type="email" class="form-control" id="email" name="email" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="asunto" class="form-label">Asunto *</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-tag"></i></span>
                                <input type="text" class="form-control" id="asunto" name="asunto" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="mensaje" class="form-label">Mensaje *</label>
                            <textarea class="form-control" id="mensaje" name="mensaje" rows="6" placeholder="Cuéntanos tu historia, propuesta o consulta..." required></textarea>
                            <small class="text-muted">Mínimo 10 caracteres</small>
                        </div>
                        
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="acepto_privacidad" required>
                            <label class="form-check-label" for="acepto_privacidad">
                                Acepto la <a href="#" target="_blank">política de privacidad</a> y el tratamiento de mis datos
                            </label>
                        </div>
                        
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="fas fa-paper-plane me-2"></i>Enviar mensaje
                        </button>
                    </form>
                </div>
            </div>
            
            <!-- Contact Info Cards -->
            <div class="row mt-4">
                <div class="col-md-4">
                    <div class="card text-center h-100">
                        <div class="card-body">
                            <i class="fas fa-newspaper fa-2x text-primary mb-3"></i>
                            <h6>Noticias y Reportajes</h6>
                            <p class="small">¿Tienes una noticia que contar?</p>
                            <a href="mailto:redaccion@elfaro.cl" class="btn btn-outline-primary btn-sm">
                                redaccion@elfaro.cl
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-center h-100">
                        <div class="card-body">
                            <i class="fas fa-ad fa-2x text-success mb-3"></i>
                            <h6>Publicidad</h6>
                            <p class="small">Promociona tu negocio con nosotros</p>
                            <a href="mailto:publicidad@elfaro.cl" class="btn btn-outline-success btn-sm">
                                publicidad@elfaro.cl
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-center h-100">
                        <div class="card-body">
                            <i class="fas fa-cog fa-2x text-warning mb-3"></i>
                            <h6>Soporte Técnico</h6>
                            <p class="small">Problemas con el sitio web</p>
                            <a href="mailto:soporte@elfaro.cl" class="btn btn-outline-warning btn-sm">
                                soporte@elfaro.cl
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Contact Sidebar -->
        <div class="col-lg-4">
            <!-- Contact Information -->
            <div class="sidebar-widget">
                <h4 class="widget-title"><i class="fas fa-info-circle me-2"></i>Información de Contacto</h4>
                <div class="contact-info">
                    <div class="contact-item mb-3">
                        <i class="fas fa-map-marker-alt text-primary me-2"></i>
                        <strong>Dirección:</strong><br>
                        <span>Av. Principal 123<br>Calama, Antofagasta<br>Chile</span>
                    </div>
                    <div class="contact-item mb-3">
                        <i class="fas fa-phone text-primary me-2"></i>
                        <strong>Teléfono:</strong><br>
                        <span>+56 2 1234 5678</span>
                    </div>
                    <div class="contact-item mb-3">
                        <i class="fas fa-envelope text-primary me-2"></i>
                        <strong>Email:</strong><br>
                        <span>info@elfaro.cl</span>
                    </div>
                    <div class="contact-item mb-3">
                        <i class="fas fa-clock text-primary me-2"></i>
                        <strong>Horarios:</strong><br>
                        <span>Lun - Vie: 9:00 - 18:00<br>Sáb: 9:00 - 13:00</span>
                    </div>
                </div>
            </div>
            
            <!-- Social Media -->
            <div class="sidebar-widget">
                <h4 class="widget-title"><i class="fas fa-share-alt me-2"></i>Síguenos</h4>
                <div class="d-grid gap-2">
                    <a href="#" class="btn btn-outline-primary">
                        <i class="fab fa-facebook-f me-2"></i>Facebook
                    </a>
                    <a href="#" class="btn btn-outline-info">
                        <i class="fab fa-twitter me-2"></i>Twitter
                    </a>
                    <a href="#" class="btn btn-outline-danger">
                        <i class="fab fa-instagram me-2"></i>Instagram
                    </a>
                    <a href="#" class="btn btn-outline-dark">
                        <i class="fab fa-youtube me-2"></i>YouTube
                    </a>
                </div>
            </div>
            
            <!-- FAQ -->
            <div class="sidebar-widget">
                <h4 class="widget-title"><i class="fas fa-question-circle me-2"></i>Preguntas Frecuentes</h4>
                <div class="accordion" id="faqAccordion">
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingOne">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne">
                                ¿Cómo puedo enviar una noticia?
                            </button>
                        </h2>
                        <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Puedes usar este formulario o escribir directamente a redaccion@elfaro.cl con todos los detalles.
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingTwo">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo">
                                ¿Cuánto tardan en responder?
                            </button>
                        </h2>
                        <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Respondemos todos los mensajes en un plazo máximo de 24 horas hábiles.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Newsletter -->
            <div class="sidebar-widget">
                <h4 class="widget-title"><i class="fas fa-envelope-open me-2"></i>Newsletter</h4>
                <p>Mantente informado con nuestro boletín semanal.</p>
                <form id="newsletter-contacto">
                    <div class="mb-3">
                        <input type="email" class="form-control" placeholder="Tu email" required>
                    </div>
                    <button type="submit" class="btn btn-success w-100">
                        <i class="fas fa-paper-plane me-2"></i>Suscribirse
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Contact form submission
    $('#contacto-form').on('submit', function(e) {
        e.preventDefault();
        
        const $form = $(this);
        const $btn = $form.find('button[type="submit"]');
        const $resultado = $('#mensaje-contacto');
        
        $btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Enviando...');
        
        $.ajax({
            url: '<?= base_url('/contacto/enviar') ?>',
            type: 'POST',
            data: $form.serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    $resultado.html(`
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle me-2"></i>
                            ${response.message}
                        </div>
                    `).show();
                    $form[0].reset();
                } else {
                    let errorHtml = '<div class="alert alert-danger">';
                    errorHtml += '<i class="fas fa-exclamation-triangle me-2"></i>';
                    
                    if (response.errors) {
                        errorHtml += '<ul class="mb-0">';
                        $.each(response.errors, function(field, error) {
                            errorHtml += `<li>${error}</li>`;
                        });
                        errorHtml += '</ul>';
                    } else {
                        errorHtml += response.message;
                    }
                    
                    errorHtml += '</div>';
                    $resultado.html(errorHtml).show();
                }
            },
            error: function() {
                $resultado.html(`
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Error de conexión. Inténtalo nuevamente.
                    </div>
                `).show();
            },
            complete: function() {
                $btn.prop('disabled', false).html('<i class="fas fa-paper-plane me-2"></i>Enviar mensaje');
            }
        });
    });
    
    // Newsletter form
    $('#newsletter-contacto').on('submit', function(e) {
        e.preventDefault();
        const email = $(this).find('input[type="email"]').val();
        alert('¡Gracias por suscribirte! Te mantendremos informado.');
        $(this)[0].reset();
    });
    
    // Character counter for message
    $('#mensaje').on('input', function() {
        const length = $(this).val().length;
        const minLength = 10;
        
        if (length < minLength) {
            $(this).addClass('is-invalid');
        } else {
            $(this).removeClass('is-invalid');
        }
    });
});
</script>