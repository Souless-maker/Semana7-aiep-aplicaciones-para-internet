<!-- Breadcrumb -->
<div class="container mt-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('/') ?>">Inicio</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('/admin') ?>">Panel Admin</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('/admin/articulos') ?>">Artículos</a></li>
            <li class="breadcrumb-item active" aria-current="page">Editar Artículo</li>
        </ol>
    </nav>
</div>

<!-- Header -->
<div class="container">
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1><i class="fas fa-edit me-2"></i>Editar Artículo</h1>
                    <p class="lead">Modifica el contenido del artículo: <strong><?= esc($articulo['titulo']) ?></strong></p>
                </div>
                <div>
                    <a href="<?= base_url('/admin/articulos') ?>" class="btn btn-outline-secondary me-2">
                        <i class="fas fa-arrow-left me-2"></i>Volver a Artículos
                    </a>
                    <a href="<?= base_url('/articulo/' . $articulo['id']) ?>" class="btn btn-outline-info" target="_blank">
                        <i class="fas fa-external-link-alt me-2"></i>Ver Publicado
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Form -->
<div class="container">
    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="fas fa-edit me-2"></i>Editar Información del Artículo</h5>
                        <div>
                            <small class="text-muted">
                                <i class="fas fa-calendar me-1"></i>
                                Creado: <?= date('d/m/Y H:i', strtotime($articulo['fecha_publicacion'])) ?>
                            </small>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div id="mensaje-editar" style="display: none;"></div>
                    
                    <form id="editar-articulo-form" enctype="multipart/form-data">
                        <input type="hidden" id="articulo_id" value="<?= $articulo['id'] ?>">
                        
                        <div class="mb-3">
                            <label for="titulo" class="form-label">Título del Artículo *</label>
                            <input type="text" class="form-control" id="titulo" name="titulo" value="<?= esc($articulo['titulo']) ?>" required>
                            <small class="text-muted">Mínimo 5 caracteres, máximo 200</small>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="categoria_id" class="form-label">Categoría *</label>
                                    <select class="form-select" id="categoria_id" name="categoria_id" required>
                                        <option value="">Seleccionar categoría...</option>
                                        <?php if (!empty($categoriasSelect)): ?>
                                            <?php foreach ($categoriasSelect as $categoria): ?>
                                                <option value="<?= $categoria['id'] ?>" <?= $categoria['id'] == $articulo['categoria_id'] ? 'selected' : '' ?>>
                                                    <?= esc($categoria['nombre']) ?>
                                                </option>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="imagen" class="form-label">
                                        Imagen del Artículo
                                        <?php if (!empty($articulo['imagen'])): ?>
                                            <span class="badge bg-success">Imagen actual</span>
                                        <?php endif; ?>
                                    </label>
                                    <input type="file" class="form-control" id="imagen" name="imagen" accept="image/*">
                                    <small class="text-muted">Formatos: JPG, PNG, GIF. Máximo 2MB. Dejar vacío para mantener imagen actual.</small>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Current image preview -->
                        <?php if (!empty($articulo['imagen'])): ?>
                            <div class="mb-3" id="current-image">
                                <label class="form-label">Imagen Actual</label>
                                <div>
                                    <img src="<?= base_url('uploads/' . $articulo['imagen']) ?>" class="img-thumbnail" style="max-height: 150px;" alt="Imagen actual">
                                    <button type="button" class="btn btn-outline-danger btn-sm ms-2" onclick="removeCurrentImage()">
                                        <i class="fas fa-trash"></i> Eliminar imagen
                                    </button>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <div class="mb-3">
                            <label for="resumen" class="form-label">Resumen/Entradilla</label>
                            <textarea class="form-control" id="resumen" name="resumen" rows="3"><?= esc($articulo['resumen']) ?></textarea>
                            <small class="text-muted">Máximo 300 caracteres. Este texto aparecerá en la página principal.</small>
                        </div>
                        
                        <div class="mb-3">
                            <label for="contenido" class="form-label">Contenido del Artículo *</label>
                            <textarea class="form-control" id="contenido" name="contenido" rows="12" required><?= esc($articulo['contenido']) ?></textarea>
                            <small class="text-muted">Contenido principal del artículo. Mínimo 10 caracteres.</small>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" id="activo" name="activo" <?= $articulo['activo'] ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="activo">
                                            <strong>Artículo publicado</strong>
                                        </label>
                                    </div>
                                    <small class="text-muted">Si no está marcado, se guardará como borrador</small>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Información de Autor</label>
                                    <input type="text" class="form-control" value="Creado por: <?= esc($articulo['autor_nombre'] ?? 'Usuario') ?>" disabled>
                                    <small class="text-muted">El autor original se mantiene sin cambios</small>
                                </div>
                            </div>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <a href="<?= base_url('/admin/articulos') ?>" class="btn btn-secondary me-md-2">
                                <i class="fas fa-times me-2"></i>Cancelar
                            </a>
                            <button type="button" class="btn btn-outline-primary me-md-2" onclick="guardarBorrador()">
                                <i class="fas fa-save me-2"></i>Guardar como Borrador
                            </button>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-check me-2"></i>Actualizar Artículo
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Sidebar -->
        <div class="col-lg-4">
            <!-- Article Stats -->
            <div class="card mb-4">
                <div class="card-header">
                    <h6 class="mb-0"><i class="fas fa-chart-line me-2"></i>Estadísticas del Artículo</h6>
                </div>
                <div class="card-body">
                    <div class="mb-2">
                        <strong>Estado actual:</strong>
                        <span class="badge bg-<?= $articulo['activo'] ? 'success' : 'warning' ?>">
                            <?= $articulo['activo'] ? 'Publicado' : 'Borrador' ?>
                        </span>
                    </div>
                    <div class="mb-2">
                        <strong>Fecha de creación:</strong><br>
                        <small><?= date('d/m/Y H:i', strtotime($articulo['fecha_publicacion'])) ?></small>
                    </div>
                    <div class="mb-2">
                        <strong>Categoría actual:</strong><br>
                        <span class="badge bg-secondary"><?= esc($articulo['categoria_nombre'] ?? 'Sin categoría') ?></span>
                    </div>
                    <div class="mb-0">
                        <strong>ID del artículo:</strong> #<?= $articulo['id'] ?>
                    </div>
                </div>
            </div>
            
            <!-- Preview Card -->
            <div class="card mb-4">
                <div class="card-header">
                    <h6 class="mb-0"><i class="fas fa-eye me-2"></i>Vista Previa</h6>
                </div>
                <div class="card-body">
                    <div id="preview-imagen" class="mb-3">
                        <?php if (!empty($articulo['imagen'])): ?>
                            <img id="preview-img" src="<?= base_url('uploads/' . $articulo['imagen']) ?>" class="img-fluid rounded" alt="Preview">
                        <?php else: ?>
                            <div class="bg-light p-3 text-center rounded">
                                <i class="fas fa-image text-muted fa-2x"></i>
                                <br><small class="text-muted">Sin imagen</small>
                            </div>
                        <?php endif; ?>
                    </div>
                    <h6 id="preview-titulo"><?= esc($articulo['titulo']) ?></h6>
                    <p id="preview-resumen" class="small text-muted"><?= esc($articulo['resumen']) ?: 'Sin resumen' ?></p>
                    <small class="text-muted">
                        <i class="fas fa-calendar me-1"></i>
                        <span id="preview-fecha"><?= date('d/m/Y H:i', strtotime($articulo['fecha_publicacion'])) ?></span>
                    </small>
                </div>
            </div>
            
            <!-- Version History -->
            <div class="card mb-4">
                <div class="card-header">
                    <h6 class="mb-0"><i class="fas fa-history me-2"></i>Historial</h6>
                </div>
                <div class="card-body">
                    <div class="timeline-item mb-2">
                        <small class="text-muted">
                            <i class="fas fa-plus-circle text-success me-1"></i>
                            Artículo creado el <?= date('d/m/Y', strtotime($articulo['fecha_publicacion'])) ?>
                        </small>
                    </div>
                    <div class="timeline-item">
                        <small class="text-muted">
                            <i class="fas fa-edit text-primary me-1"></i>
                            Editando ahora...
                        </small>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="card">
                <div class="card-header">
                    <h6 class="mb-0"><i class="fas fa-bolt me-2"></i>Acciones Rápidas</h6>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <a href="<?= base_url('/articulo/' . $articulo['id']) ?>" class="btn btn-outline-info btn-sm" target="_blank">
                            <i class="fas fa-external-link-alt me-2"></i>Ver en el sitio
                        </a>
                        <button class="btn btn-outline-warning btn-sm" onclick="cambiarEstadoRapido()">
                            <i class="fas fa-toggle-on me-2"></i>
                            <?= $articulo['activo'] ? 'Despublicar' : 'Publicar' ?>
                        </button>
                        <button class="btn btn-outline-danger btn-sm" onclick="eliminarArticulo()">
                            <i class="fas fa-trash me-2"></i>Eliminar artículo
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>

// Verificar jQuery disponible
if (typeof $ === 'undefined') {
    console.error('jQuery no disponible en articulo_editar.php');
    alert('Error: No se puede inicializar el formulario. Refresca la página.');
} else {
    console.log('Inicializando formulario editar artículo...');
}

$(document).ready(function() {
    // Contador de caracteres para resumen
    $('#resumen').on('input', function() {
        const length = $(this).val().length;
        const maxLength = 300;
        const remaining = maxLength - length;
        
        $(this).next('.text-muted').text(remaining + ' caracteres restantes (máximo 300)');
        
        if (remaining < 50) {
            $(this).next('.text-muted').addClass('text-warning');
        } else {
            $(this).next('.text-muted').removeClass('text-warning');
        }
    });
    
    // Vista previa - Título
    $('#titulo').on('input', function() {
        const titulo = $(this).val() || 'Sin título';
        $('#preview-titulo').text(titulo);
    });

    // Validación de título único
    let tituloTimeout;
    $('#titulo').on('blur', function() {
        const titulo = $(this).val().trim();
        const articuloId = $('#articulo_id').val();
        
        if (titulo.length > 5) {
            clearTimeout(tituloTimeout);
            
            tituloTimeout = setTimeout(function() {
                $.ajax({
                    url: '<?= base_url('/admin/articulos/verificarTitulo') ?>',
                    type: 'POST',
                    data: { 
                        titulo: titulo,
                        articulo_id: articuloId,
                        '<?= csrf_token() ?>': '<?= csrf_hash() ?>'
                    },
                    dataType: 'json',
                    success: function(response) {
                        $('#titulo').next('.invalid-feedback').remove();
                        
                        if (response.existe) {
                            $('#titulo').addClass('is-invalid');
                            $('#titulo').after('<div class="invalid-feedback">Ya existe otro artículo con este título</div>');
                        } else {
                            $('#titulo').removeClass('is-invalid');
                        }
                    },
                    error: function() {
                        console.log('Error verificando título único');
                    }
                });
            }, 500);
        }
    });

    // Vista previa - Resumen
    $('#resumen').on('input', function() {
        const resumen = $(this).val() || 'Sin resumen';
        $('#preview-resumen').text(resumen);
    });
    
    // Vista previa de imagen
    $('#imagen').on('change', function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                $('#preview-img').attr('src', e.target.result);
                $('#preview-imagen img, #preview-imagen div').show();
            };
            reader.readAsDataURL(file);
        }
    });
    
    // Envío de formulario
    $('#editar-articulo-form').on('submit', function(e) {
        e.preventDefault();
        
        const form = $(this);
        const btn = form.find('button[type="submit"]');
        const resultado = $('#mensaje-editar');
        const articuloId = $('#articulo_id').val();
        
        btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Actualizando...');
        
        const formData = new FormData(this);
        
        $.ajax({
            url: '<?= base_url('/admin/articulos/actualizar/') ?>' + articuloId,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    resultado.html(
                        '<div class="alert alert-success">' +
                        '<i class="fas fa-check-circle me-2"></i>' +
                        response.message +
                        '</div>'
                    ).show();
                    
                    setTimeout(function() {
                        window.location.href = '<?= base_url('/articulo/') ?>' + articuloId;
                    }, 1500);
                } else {
                    let errorHtml = '<div class="alert alert-danger">';
                    errorHtml += '<i class="fas fa-exclamation-triangle me-2"></i>';
                    
                    if (response.errors) {
                        errorHtml += '<ul class="mb-0">';
                        for (const field in response.errors) {
                            errorHtml += '<li>' + response.errors[field] + '</li>';
                        }
                        errorHtml += '</ul>';
                    } else {
                        errorHtml += response.message;
                    }
                    
                    errorHtml += '</div>';
                    resultado.html(errorHtml).show();
                }
            },
            error: function() {
                resultado.html(
                    '<div class="alert alert-danger">' +
                    '<i class="fas fa-exclamation-triangle me-2"></i>' +
                    'Error de conexión. Inténtalo nuevamente.' +
                    '</div>'
                ).show();
            },
            complete: function() {
                btn.prop('disabled', false).html('<i class="fas fa-check me-2"></i>Actualizar Artículo');
            }
        });
    });
    
    // Auto-guardado
    let autoSaveTimeout;
    function autoSave() {
        clearTimeout(autoSaveTimeout);
        autoSaveTimeout = setTimeout(function() {
            const formData = {
                id: $('#articulo_id').val(),
                titulo: $('#titulo').val(),
                resumen: $('#resumen').val(),
                contenido: $('#contenido').val(),
                categoria_id: $('#categoria_id').val()
            };
            localStorage.setItem('articulo_edit_draft_' + formData.id, JSON.stringify(formData));
            console.log('Cambios auto-guardados localmente');
        }, 5000);
    }
    
    $('#titulo, #resumen, #contenido, #categoria_id').on('input change', autoSave);
});

// Guardar como borrador
function guardarBorrador() {
    $('#activo').prop('checked', false);
    $('#editar-articulo-form').trigger('submit');
}

// Eliminar imagen actual
function removeCurrentImage() {
    if (confirm('¿Estás seguro de que quieres eliminar la imagen actual?')) {
        $('#current-image').hide();
        $('<input>').attr({
            type: 'hidden',
            name: 'remove_image',
            value: '1'
        }).appendTo('#editar-articulo-form');
        
        $('#preview-imagen').html(
            '<div class="bg-light p-3 text-center rounded">' +
            '<i class="fas fa-image text-muted fa-2x"></i>' +
            '<br><small class="text-muted">Sin imagen</small>' +
            '</div>'
        );
    }
}

// Cambiar estado rápido
function cambiarEstadoRapido() {
    const articuloId = $('#articulo_id').val();
    const currentStatus = $('#activo').is(':checked');
    const newStatus = !currentStatus;
    
    $.ajax({
        url: '<?= base_url('/admin/articulos/cambiarEstado') ?>',
        type: 'POST',
        data: { 
            id: articuloId, 
            activo: newStatus ? 1 : 0,
            '<?= csrf_token() ?>': '<?= csrf_hash() ?>'
        },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                alert('Estado cambiado exitosamente');
                location.reload();
            } else {
                alert('Error: ' + response.message);
            }
        }
    });
}

// Eliminar artículo
function eliminarArticulo() {
    if (confirm('¿Estás seguro de que quieres eliminar este artículo? Esta acción no se puede deshacer.')) {
        const articuloId = $('#articulo_id').val();
        
        $.ajax({
            url: '<?= base_url('/admin/articulos/eliminar') ?>',
            type: 'POST',
            data: { 
                id: articuloId,
                '<?= csrf_token() ?>': '<?= csrf_hash() ?>'
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    alert('Artículo eliminado correctamente');
                    window.location.href = '<?= base_url('/admin/articulos') ?>';
                } else {
                    alert('Error: ' + response.message);
                }
            }
        });
    }
}
</script>