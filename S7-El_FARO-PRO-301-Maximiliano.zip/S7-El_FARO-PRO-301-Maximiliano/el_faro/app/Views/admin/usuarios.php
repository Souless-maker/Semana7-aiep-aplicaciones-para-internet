<!-- Breadcrumb -->
<div class="container mt-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('/') ?>">Inicio</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('/admin') ?>">Panel Admin</a></li>
            <li class="breadcrumb-item active" aria-current="page">Gestión de Usuarios</li>
        </ol>
    </nav>
</div>

<!-- Header -->
<div class="container">
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1><i class="fas fa-users me-2"></i>Gestión de Usuarios</h1>
                    <p class="lead">Administra los usuarios registrados en la plataforma</p>
                </div>
                <div>
                    <a href="<?= base_url('/admin') ?>" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-left me-2"></i>Volver al Panel
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Alerts -->
<div class="container">
    <div id="mensaje-usuarios" style="display: none;"></div>
    
    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i>
            <?= session()->getFlashdata('success') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if (session()->getFlashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <?= session()->getFlashdata('error') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
</div>

<!-- Statistics Cards -->
<div class="container">
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card text-white bg-primary">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?= count($usuarios) ?></h4>
                            <p class="mb-0">Total Usuarios</p>
                        </div>
                        <i class="fas fa-users fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-success">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?= count(array_filter($usuarios, function($u) { return $u['activo'] == 1; })) ?></h4>
                            <p class="mb-0">Usuarios Activos</p>
                        </div>
                        <i class="fas fa-user-check fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-danger">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?= count(array_filter($usuarios, function($u) { return $u['tipo_usuario'] == 'admin'; })) ?></h4>
                            <p class="mb-0">Administradores</p>
                        </div>
                        <i class="fas fa-user-shield fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-info">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?= count(array_filter($usuarios, function($u) { return $u['tipo_usuario'] === 'usuario'; })) ?></h4>
                            <p class="mb-0">Usuarios Regulares</p>
                        </div>
                        <i class="fas fa-user fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Users Table -->
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="fas fa-list me-2"></i>Listado de Usuarios Registrados
                        </h5>
                        <div class="d-flex gap-2">
                            <!-- Search Box -->
                            <div class="input-group" style="width: 250px;">
                                <input type="text" class="form-control" id="buscar-usuario" placeholder="Buscar usuario...">
                                <button class="btn btn-outline-secondary" type="button">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                            
                            <!-- Filter Dropdown -->
                            <div class="dropdown">
                                <button class="btn btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                    <i class="fas fa-filter me-1"></i>Filtrar
                                </button>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="#" data-filter="todos">Todos los usuarios</a></li>
                                    <li><a class="dropdown-item" href="#" data-filter="activos">Solo activos</a></li>
                                    <li><a class="dropdown-item" href="#" data-filter="inactivos">Solo inactivos</a></li>
                                    <li><a class="dropdown-item" href="#" data-filter="admin">Administradores</a></li>
                                    <li><a class="dropdown-item" href="#" data-filter="usuarios">Usuarios regulares</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?php if (!empty($usuarios)): ?>
                        <div class="table-responsive">
                            <table class="table table-hover" id="tabla-usuarios">
                                <thead class="table-light">
                                    <tr>
                                        <th>ID</th>
                                        <th>Nombre</th>
                                        <th>Email</th>
                                        <th>Tipo</th>
                                        <th>Fecha Registro</th>
                                        <th>Estado</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($usuarios as $usuario): ?>
                                        <tr data-tipo="<?= $usuario['tipo_usuario'] ?>" data-activo="<?= $usuario['activo'] ?>">
                                            <td><?= $usuario['id'] ?></td>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="avatar-circle bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 32px; height: 32px;">
                                                        <?= strtoupper(substr($usuario['nombre'], 0, 1)) ?>
                                                    </div>
                                                    <div>
                                                        <strong><?= esc($usuario['nombre']) ?></strong>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><?= esc($usuario['email']) ?></td>
                                            <td>
                                                <span class="badge bg-<?= $usuario['tipo_usuario'] === 'admin' ? 'danger' : 'primary' ?>">
                                                    <?= $usuario['tipo_usuario'] === 'admin' ? 'Administrador' : 'Usuario' ?>
                                                </span>
                                            </td>
                                            <td>
                                                <small>
                                                    <?= date('d/m/Y H:i', strtotime($usuario['fecha_registro'])) ?>
                                                </small>
                                            </td>
                                            <td>
                                                <span class="badge bg-<?= $usuario['activo'] ? 'success' : 'secondary' ?>">
                                                    <?= $usuario['activo'] ? 'Activo' : 'Inactivo' ?>
                                                </span>
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <a href="<?= base_url('/admin/usuarios/ver/' . $usuario['id']) ?>" class="btn btn-outline-info" title="Ver detalles">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    
                                                    <?php if ($usuario['id'] != session()->get('usuario_id')): ?>
                                                        <button class="btn btn-outline-warning" onclick="cambiarEstado(<?= $usuario['id'] ?>, <?= $usuario['activo'] ? 0 : 1 ?>)" title="<?= $usuario['activo'] ? 'Desactivar' : 'Activar' ?>">
                                                            <i class="fas fa-<?= $usuario['activo'] ? 'user-times' : 'user-check' ?>"></i>
                                                        </button>
                                                        
                                                        <button class="btn btn-outline-danger" onclick="eliminarUsuario(<?= $usuario['id'] ?>)" title="Eliminar">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    <?php else: ?>
                                                        <span class="btn btn-outline-secondary disabled" title="No puedes modificar tu propia cuenta">
                                                            <i class="fas fa-lock"></i>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!-- Pagination -->
                        <div class="mt-3">
                            <small class="text-muted">
                                Mostrando <?= count($usuarios) ?> usuario(s) registrado(s)
                            </small>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-users fa-4x text-muted mb-3"></i>
                            <h5>No hay usuarios registrados</h5>
                            <p class="text-muted">Los nuevos registros aparecerán aquí automáticamente.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Export Options -->
<div class="container mt-3">
    <div class="card">
        <div class="card-header">
            <h6 class="mb-0"><i class="fas fa-download me-2"></i>Opciones de Exportación</h6>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <p class="small">Exporta la lista de usuarios para análisis externo o backup.</p>
                </div>
                <div class="col-md-6 text-end">
                    <div class="btn-group">
                        <button class="btn btn-outline-success btn-sm" onclick="exportarCSV()">
                            <i class="fas fa-file-csv me-1"></i>Exportar CSV
                        </button>
                        <button class="btn btn-outline-primary btn-sm" onclick="exportarExcel()">
                            <i class="fas fa-file-excel me-1"></i>Exportar Excel
                        </button>
                        <button class="btn btn-outline-danger btn-sm" onclick="exportarPDF()">
                            <i class="fas fa-file-pdf me-1"></i>Exportar PDF
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirmar Eliminación</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>¿Estás seguro de que quieres eliminar este usuario?</p>
                <p><strong>Esta acción no se puede deshacer.</strong></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-danger" id="confirmar-eliminar">Eliminar Usuario</button>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Search functionality
    $('#buscar-usuario').on('keyup', function() {
        const searchTerm = $(this).val().toLowerCase();
        $('#tabla-usuarios tbody tr').each(function() {
            const text = $(this).text().toLowerCase();
            $(this).toggle(text.includes(searchTerm));
        });
    });
    
    // Filter functionality
    $('[data-filter]').on('click', function(e) {
        e.preventDefault();
        const filter = $(this).data('filter');
        
        $('#tabla-usuarios tbody tr').each(function() {
            const tipo = $(this).data('tipo');
            const activo = $(this).data('activo');
            let show = true;
            
            switch(filter) {
                case 'activos':
                    show = activo == 1;
                    break;
                case 'inactivos':
                    show = activo == 0;
                    break;
                case 'admin':
                    show = tipo === 'admin';
                    break;
                case 'usuarios':
                    show = tipo === 'usuario';
                    break;
                default:
                    show = true;
            }
            
            $(this).toggle(show);
        });
    });
});

// Change user status
function cambiarEstado(id, activo) {
    const accion = activo ? 'activar' : 'desactivar';
    
    if (confirm(`¿Seguro que quieres ${accion} este usuario?`)) {
        $.ajax({
            url: '<?= base_url('/admin/usuarios/cambiarEstado') ?>',
            type: 'POST',
            data: { id: id, activo: activo },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    $('#mensaje-usuarios').html(`
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="fas fa-check-circle me-2"></i>
                            ${response.message}
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    `).show();
                    
                    // Reload page after 1 second
                    setTimeout(() => location.reload(), 1000);
                } else {
                    $('#mensaje-usuarios').html(`
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            ${response.message}
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    `).show();
                }
            },
            error: function() {
                $('#mensaje-usuarios').html(`
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Error de conexión. Inténtalo nuevamente.
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                `).show();
            }
        });
    }
}

// Delete user
let usuarioAEliminar = null;

function eliminarUsuario(id) {
    usuarioAEliminar = id;
    $('#deleteModal').modal('show');
}

$('#confirmar-eliminar').on('click', function() {
    if (usuarioAEliminar) {
        $.ajax({
            url: '<?= base_url('/admin/usuarios/eliminar') ?>',
            type: 'POST',
            data: { id: usuarioAEliminar },
            dataType: 'json',
            success: function(response) {
                $('#deleteModal').modal('hide');
                
                if (response.success) {
                    $('#mensaje-usuarios').html(`
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="fas fa-check-circle me-2"></i>
                            ${response.message}
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    `).show();
                    
                    // Reload page after 1 second
                    setTimeout(() => location.reload(), 1000);
                } else {
                    $('#mensaje-usuarios').html(`
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            ${response.message}
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    `).show();
                }
            },
            error: function() {
                $('#deleteModal').modal('hide');
                $('#mensaje-usuarios').html(`
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Error de conexión. Inténtalo nuevamente.
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                `).show();
            }
        });
    }
});

// Export functions
function exportarCSV() {
    alert('Exportando a CSV... (función por implementar)');
}

function exportarExcel() {
    alert('Exportando a Excel... (función por implementar)');
}

function exportarPDF() {
    alert('Exportando a PDF... (función por implementar)');
}
</script>