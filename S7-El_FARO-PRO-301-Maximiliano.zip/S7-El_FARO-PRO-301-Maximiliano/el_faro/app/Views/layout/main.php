<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $titulo ?? 'El Faro - Noticias de la Comunidad' ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-gray: #f8f9fa;
            --dark-gray: #6c757d;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
        }
        
        .navbar-brand {
            font-weight: bold;
            font-size: 1.5rem;
            color: var(--primary-color) !important;
        }
        
        .navbar {
            background-color: white !important;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .hero-section {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 100px 0;
            margin-bottom: 50px;
        }
        
        .hero-title {
            font-size: 3.5rem;
            font-weight: 300;
            margin-bottom: 20px;
        }
        
        .hero-subtitle {
            font-size: 1.3rem;
            margin-bottom: 30px;
            opacity: 0.9;
        }
        
        .card {
            border: none;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
            margin-bottom: 30px;
        }
        
        .card:hover {
            transform: translateY(-5px);
        }
        
        .card-img-top {
            height: 200px;
            object-fit: cover;
        }
        
        .btn-primary {
            background-color: var(--secondary-color);
            border-color: var(--secondary-color);
        }
        
        .btn-primary:hover {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .section-title {
            color: var(--primary-color);
            font-weight: 600;
            margin-bottom: 30px;
            position: relative;
        }
        
        .section-title:after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 0;
            width: 50px;
            height: 3px;
            background-color: var(--accent-color);
        }
        
        .sidebar-widget {
            background-color: var(--light-gray);
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        
        .widget-title {
            color: var(--primary-color);
            font-weight: 600;
            margin-bottom: 20px;
            font-size: 1.2rem;
        }
        
        .category-link {
            display: block;
            padding: 10px 15px;
            color: var(--dark-gray);
            text-decoration: none;
            border-bottom: 1px solid #e9ecef;
            transition: all 0.3s ease;
        }
        
        .category-link:hover {
            background-color: var(--secondary-color);
            color: white;
            text-decoration: none;
        }
        
        .category-link:last-child {
            border-bottom: none;
        }
        
        .footer {
            background-color: var(--primary-color);
            color: white;
            padding: 50px 0 20px 0;
            margin-top: 100px;
        }
        
        .search-form {
            max-width: 400px;
        }
        
        .article-meta {
            font-size: 0.9rem;
            color: var(--dark-gray);
            margin-bottom: 15px;
        }
        
        .article-content {
            font-size: 1.1rem;
            line-height: 1.8;
        }
        
        .breadcrumb {
            background-color: transparent;
            padding: 0;
        }
        
        .breadcrumb-item a {
            color: var(--secondary-color);
            text-decoration: none;
        }
        
        .alert {
            border-radius: 10px;
            border: none;
        }
        
        @media (max-width: 768px) {
            .hero-title {
                font-size: 2.5rem;
            }
            
            .hero-subtitle {
                font-size: 1.1rem;
            }
            
            .navbar-brand {
                font-size: 1.2rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
        <div class="container">
            <a class="navbar-brand" href="<?= base_url('/') ?>">
                <i class="fas fa-lighthouse me-2"></i>El Faro
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('/') ?>">Inicio</a>
                    </li>
                    
                    <?php if (!empty($categorias)): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                                Secciones
                            </a>
                            <ul class="dropdown-menu">
                                <?php foreach ($categorias as $categoria): ?>
                                    <li>
                                        <a class="dropdown-item" href="<?= base_url('/seccion/' . $categoria['slug']) ?>">
                                            <?= esc($categoria['nombre']) ?>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('/contacto') ?>">Contacto</a>
                    </li>
                </ul>
                
                <!-- Search Form -->
                <form class="d-flex me-3 search-form" method="GET" action="<?= base_url('/buscar') ?>">
                    <input class="form-control me-2" type="search" name="q" placeholder="Buscar noticias..." aria-label="Search">
                    <button class="btn btn-outline-primary" type="submit">
                        <i class="fas fa-search"></i>
                    </button>
                </form>
                
                <!-- User Menu -->
                <ul class="navbar-nav">
                    <?php $session = session(); ?>
                    <?php if ($session->get('usuario_logueado')): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-user me-1"></i>
                                <?= esc($session->get('usuario_nombre')) ?>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="<?= base_url('/usuario/perfil') ?>">Mi Perfil</a></li>
                                <?php if ($session->get('usuario_tipo') === 'admin'): ?>
                                    <li><a class="dropdown-item" href="<?= base_url('/admin') ?>">Panel Admin</a></li>
                                <?php endif; ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="<?= base_url('/usuario/logout') ?>">Cerrar Sesión</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= base_url('/usuario/login') ?>">
                                <i class="fas fa-sign-in-alt me-1"></i>Login
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= base_url('/usuario/registro') ?>">
                                <i class="fas fa-user-plus me-1"></i>Registro
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
<main style="padding-top: 76px;">
    <?php
    // Protección: asegurar que $content siempre exista
    $content = $content ?? '';
    
    if (is_string($content)) {
        echo $content;
    } elseif (isset($content['view'])) {
        echo view($content['view'], $content['data'] ?? []);
    } else {
        echo $content;
    }
    ?>
</main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <h5><i class="fas fa-lighthouse me-2"></i>El Faro</h5>
                    <p>Tu fuente confiable de noticias locales. Manteniendo informada a nuestra comunidad con las últimas noticias, eventos y acontecimientos importantes.</p>
                </div>
                <div class="col-lg-2 col-md-6">
                    <h6>Enlaces Rápidos</h6>
                    <ul class="list-unstyled">
                        <li><a href="<?= base_url('/') ?>" class="text-white-50">Inicio</a></li>
                        <li><a href="<?= base_url('/contacto') ?>" class="text-white-50">Contacto</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h6>Secciones</h6>
                    <ul class="list-unstyled">
                        <?php if (!empty($categorias)): ?>
                            <?php foreach (array_slice($categorias, 0, 4) as $categoria): ?>
                                <li>
                                    <a href="<?= base_url('/seccion/' . $categoria['slug']) ?>" class="text-white-50">
                                        <?= esc($categoria['nombre']) ?>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h6>Síguenos</h6>
                    <div class="social-links">
                        <a href="#" class="text-white-50 me-3"><i class="fab fa-facebook-f fa-lg"></i></a>
                        <a href="#" class="text-white-50 me-3"><i class="fab fa-twitter fa-lg"></i></a>
                        <a href="#" class="text-white-50 me-3"><i class="fab fa-instagram fa-lg"></i></a>
                        <a href="#" class="text-white-50"><i class="fab fa-youtube fa-lg"></i></a>
                    </div>
                </div>
            </div>
            <hr class="my-4">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <p class="mb-0">&copy; 2025 El Faro. Todos los derechos reservados.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <small class="text-white-50">Desarrollado con CodeIgniter 4</small>
                </div>
            </div>
        </div>
    </footer>

    <!-- jQuery (debe ir antes de Bootstrap) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!--AL FINAL: Scripts personalizados -->
<?= $this->renderSection('scripts') ?>

<script>
// Esperar a que jQuery esté completamente cargado
(function checkjQuery() {
    if (typeof jQuery !== 'undefined') {
        console.log('✓ jQuery cargado - versión: ' + jQuery.fn.jquery);
        initializeGlobalScripts();
    } else {
        console.log('Esperando jQuery...');
        setTimeout(checkjQuery, 50);
    }
})();

function initializeGlobalScripts() {
    jQuery(document).ready(function($) {
        console.log('✓ Scripts globales inicializados');
        
        // Smooth scrolling
        $('a[href^="#"]').on('click', function(e) {
            const target = $(this).attr('href');
            if ($(target).length) {
                e.preventDefault();
                $('html, body').animate({
                    scrollTop: $(target).offset().top - 70
                }, 500);
            }
        });
        
        // Auto-hide alerts
        if ($('.alert').length) {
            setTimeout(function() {
                $('.alert').fadeOut('slow');
            }, 5000);
        }
        
        // Search form validation
        $('form[action*="buscar"]').on('submit', function(e) {
            const searchInput = $(this).find('input[name="q"]');
            if (searchInput.val().trim().length < 2) {
                e.preventDefault();
                alert('Por favor ingresa al menos 2 caracteres para buscar.');
                searchInput.focus();
            }
        });
    });
}
</script>