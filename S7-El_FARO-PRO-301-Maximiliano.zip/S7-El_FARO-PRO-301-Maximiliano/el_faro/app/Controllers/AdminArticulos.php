<?php

namespace App\Controllers;

use App\Models\ArticuloModel;
use App\Models\CategoriaModel;
use App\Models\UsuarioModel;

class AdminArticulos extends BaseController
{
    protected $articuloModel;
    protected $categoriaModel;
    protected $usuarioModel;
    
    public function __construct()
    {
        $this->articuloModel = new ArticuloModel();
        $this->categoriaModel = new CategoriaModel();
        $this->usuarioModel = new UsuarioModel();
    }
    
    public function index()
    {
        $session = session();
        
        if (!$session->get('usuario_logueado') || $session->get('usuario_tipo') !== 'admin') {
            return redirect()->to('/usuario/login');
        }
        
        //  CAMBIO CRÍTICO: Usar método que trae TODOS los artículos (incluidos borradores)
        $articulos = $this->articuloModel->obtenerTodosLosArticulos();
        
        $data = [
            'titulo' => 'El Faro - Gestión de Artículos',
            'categorias' => $this->categoriaModel->obtenerCategoriasActivas(),
            'articulos' => $articulos
        ];
        
        $data['content'] = view('admin/articulos', $data);
        return view('layout/main', $data);
    }
    
    public function crear()
    {
        $session = session();
        
        if (!$session->get('usuario_logueado') || $session->get('usuario_tipo') !== 'admin') {
            return redirect()->to('/usuario/login');
        }
        
        $data = [
            'titulo' => 'El Faro - Crear Artículo',
            'categorias' => $this->categoriaModel->obtenerCategoriasActivas(),
            'categoriasSelect' => $this->categoriaModel->obtenerCategoriasActivas()
        ];
        
        $data['content'] = view('admin/articulo_crear', $data);
        return view('layout/main', $data);
    }
    
    public function guardar()
    {
        $session = session();
        
        if (!$session->get('usuario_logueado') || $session->get('usuario_tipo') !== 'admin') {
            return $this->response->setJSON(['success' => false, 'message' => 'No autorizado']);
        }

        // VERIFICACIÓN DE TÍTULO DUPLICADO PRIMERO
        $titulo = trim($this->request->getPost('titulo'));
        if (empty($titulo)) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'El título es obligatorio'
            ]);
        }

        $existeTitulo = $this->articuloModel->where('titulo', $titulo)->first();
        if ($existeTitulo) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Ya existe un artículo con ese título. Por favor, usa un título diferente.'
            ]);
        }
        
        // Validaciones
        $reglas = [
            'titulo' => 'required|min_length[5]|max_length[200]',
            'contenido' => 'required|min_length[10]',
            'categoria_id' => 'required|integer',
            'resumen' => 'max_length[300]'
        ];
        
        if (!$this->validate($reglas)) {
            return $this->response->setJSON([
                'success' => false,
                'errors' => $this->validator->getErrors()
            ]);
        }
        
        // PREPARAR DATOS CON FECHA_CREACION
        $datos = [
            'titulo' => $titulo,
            'contenido' => $this->request->getPost('contenido'),
            'resumen' => $this->request->getPost('resumen'),
            'categoria_id' => $this->request->getPost('categoria_id'),
            'usuario_id' => $session->get('usuario_id'),
            'activo' => $this->request->getPost('activo') ? 1 : 0,
            'fecha_creacion' => date('Y-m-d H:i:s')  //Usar fecha_creacion
        ];
        
        //Manejo de imagen mejorado
        $imagen = $this->request->getFile('imagen');
        if ($imagen && $imagen->isValid() && !$imagen->hasMoved()) {
            // Crear directorio si no existe
            $uploadPath = WRITEPATH . '../public/uploads/';
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            
            // Validar tipo y tamaño
            $tiposPermitidos = ['image/jpeg', 'image/png', 'image/gif'];
            if (!in_array($imagen->getMimeType(), $tiposPermitidos)) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Formato de imagen no válido. Solo JPG, PNG, GIF.'
                ]);
            }
            
            if ($imagen->getSize() > 2 * 1024 * 1024) { // 2MB
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'La imagen es muy grande. Máximo 2MB.'
                ]);
            }
            
            $newName = $imagen->getRandomName();
            $imagen->move($uploadPath, $newName);
            $datos['imagen'] = $newName;
        }
        
        // Guardar artículo
        try {
            $articuloId = $this->articuloModel->insert($datos);
            
            if ($articuloId) {
                return $this->response->setJSON([
                    'success' => true,
                    'message' => 'Artículo creado exitosamente.',
                    'articulo_id' => $articuloId
                ]);
            } else {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Error al crear el artículo.'
                ]);
            }
        } catch (\Exception $e) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Error del servidor: ' . $e->getMessage()
            ]);
        }
    }
    
    public function editar($id = null)
    {
        $session = session();
        
        if (!$session->get('usuario_logueado') || $session->get('usuario_tipo') !== 'admin') {
            return redirect()->to('/usuario/login');
        }
        
        if (!$id) {
            return redirect()->to('/admin/articulos');
        }
        
        //USAR MÉTODO PARA ADMIN (sin filtro activo)
        $articulo = $this->articuloModel->obtenerArticuloParaAdmin($id);
        
        if (!$articulo) {
            return redirect()->to('/admin/articulos')->with('error', 'Artículo no encontrado.');
        }
        
        $data = [
            'titulo' => 'El Faro - Editar Artículo',
            'categorias' => $this->categoriaModel->obtenerCategoriasActivas(),
            'categoriasSelect' => $this->categoriaModel->obtenerCategoriasActivas(),
            'articulo' => $articulo
        ];
        
        $data['content'] = view('admin/articulo_editar', $data);
        return view('layout/main', $data);
    }
    
    public function actualizar($id = null)
    {
        $session = session();
        
        if (!$session->get('usuario_logueado') || $session->get('usuario_tipo') !== 'admin') {
            return $this->response->setJSON(['success' => false, 'message' => 'No autorizado']);
        }
        
        if (!$id) {
            return $this->response->setJSON(['success' => false, 'message' => 'ID de artículo requerido']);
        }
        
        // Verificar título duplicado (excluyendo el actual)
        $titulo = trim($this->request->getPost('titulo'));
        if (!empty($titulo)) {
            $existeTitulo = $this->articuloModel->where('titulo', $titulo)->where('id !=', $id)->first();
            if ($existeTitulo) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Ya existe otro artículo con ese título.'
                ]);
            }
        }
        
        $reglas = [
            'titulo' => 'required|min_length[5]|max_length[200]',
            'contenido' => 'required|min_length[10]',
            'categoria_id' => 'required|integer',
            'resumen' => 'max_length[300]'
        ];
        
        if (!$this->validate($reglas)) {
            return $this->response->setJSON([
                'success' => false,
                'errors' => $this->validator->getErrors()
            ]);
        }
        
        $datos = [
            'titulo' => $titulo,
            'contenido' => $this->request->getPost('contenido'),
            'resumen' => $this->request->getPost('resumen'),
            'categoria_id' => $this->request->getPost('categoria_id'),
            'activo' => $this->request->getPost('activo') ? 1 : 0
        ];
        
        // Manejar imagen si se subió una nueva
        $imagen = $this->request->getFile('imagen');
        if ($imagen && $imagen->isValid() && !$imagen->hasMoved()) {
            $uploadPath = WRITEPATH . '../public/uploads/';
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            
            $newName = $imagen->getRandomName();
            $imagen->move($uploadPath, $newName);
            $datos['imagen'] = $newName;
        }
        
        if ($this->articuloModel->update($id, $datos)) {
            return $this->response->setJSON([
                'success' => true,
                'message' => 'Artículo actualizado exitosamente.',
                'articulo_id' => $id
            ]);
        } else {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Error al actualizar el artículo.'
            ]);
        }
    }
    
    public function eliminar()
    {
        $session = session();
        
        if (!$session->get('usuario_logueado') || $session->get('usuario_tipo') !== 'admin') {
            return $this->response->setJSON(['success' => false, 'message' => 'No autorizado']);
        }
        
        $id = $this->request->getPost('id');
        
        if (!$id) {
            return $this->response->setJSON(['success' => false, 'message' => 'ID de artículo requerido']);
        }
        
        // Obtener artículo para eliminar imagen si existe
        $articulo = $this->articuloModel->find($id);
        if ($articulo && !empty($articulo['imagen'])) {
            $rutaImagen = WRITEPATH . '../public/uploads/' . $articulo['imagen'];
            if (file_exists($rutaImagen)) {
                unlink($rutaImagen);
            }
        }
        
        if ($this->articuloModel->delete($id)) {
            return $this->response->setJSON([
                'success' => true,
                'message' => 'Artículo eliminado correctamente.'
            ]);
        } else {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Error al eliminar el artículo.'
            ]);
        }
    }
    
    public function cambiarEstado()
    {
        $session = session();
        
        if (!$session->get('usuario_logueado') || $session->get('usuario_tipo') !== 'admin') {
            return $this->response->setJSON(['success' => false, 'message' => 'No autorizado']);
        }
        
        $id = $this->request->getPost('id');
        $activo = $this->request->getPost('activo');
        
        if ($this->articuloModel->update($id, ['activo' => $activo])) {
            $estado = $activo ? 'publicado' : 'despublicado';
            return $this->response->setJSON(['success' => true, 'message' => "Artículo $estado correctamente"]);
        } else {
            return $this->response->setJSON(['success' => false, 'message' => 'Error al cambiar el estado del artículo']);
        }
    }

    //IMPLEMENTACIÓN CORRECTA DE VERIFICAR TÍTULO
    public function verificarTitulo()
    {
        $session = session();
        
        if (!$session->get('usuario_logueado') || $session->get('usuario_tipo') !== 'admin') {
            return $this->response->setJSON(['existe' => false]);
        }

        $titulo = trim($this->request->getPost('titulo'));
        $articuloId = $this->request->getPost('articulo_id'); // Para edición
        
        if (empty($titulo)) {
            return $this->response->setJSON(['existe' => false]);
        }

        $query = $this->articuloModel->where('titulo', $titulo);
        
        // Si es edición, excluir el artículo actual
        if ($articuloId) {
            $query = $query->where('id !=', $articuloId);
        }
        
        $existe = $query->first();
        
        return $this->response->setJSON(['existe' => $existe ? true : false]);
    }
}