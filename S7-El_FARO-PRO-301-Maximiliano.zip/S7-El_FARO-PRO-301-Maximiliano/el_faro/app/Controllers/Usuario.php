<?php

namespace App\Controllers;

use App\Models\UsuarioModel;
use App\Models\CategoriaModel;

class Usuario extends BaseController
{
    protected $usuarioModel;
    protected $categoriaModel;
    
    public function __construct()
    {
        $this->usuarioModel = new UsuarioModel();
        $this->categoriaModel = new CategoriaModel();
    }
    
 public function login()
{
    // Si viene POST, procesar login directamente
    if ($this->request->getMethod() === 'POST') {
        return $this->autenticar();
    }
    
    // Si no, mostrar formulario
    $data = [
        'titulo' => 'El Faro - Iniciar Sesión',
        'categorias' => $this->categoriaModel->obtenerCategoriasActivas()
    ];
    
    $data['content'] = view('usuario/login', $data);
    return view('layout/main', $data);
    }

    public function registro()
    {
        $data = [
            'titulo' => 'El Faro - Registro',
            'categorias' => $this->categoriaModel->obtenerCategoriasActivas()
        ];
        
            // Lo importante: asegura la variable $content
    $data['content'] = view('usuario/registro', $data);

    return view('layout/main', $data);
    }
    
    public function autenticar()
    {
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');
        
        if (empty($email) || empty($password)) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Email y contraseña son obligatorios.'
            ]);
        }
        
        $usuario = $this->usuarioModel->verificarCredenciales($email, $password);
        
        if ($usuario) {
            $session = session();
            $session->set([
                'usuario_id' => $usuario['id'],
                'usuario_nombre' => $usuario['nombre'],
                'usuario_email' => $usuario['email'],
                'usuario_tipo' => $usuario['tipo_usuario'],
                'usuario_logueado' => true
            ]);
            
            return $this->response->setJSON([
                'success' => true,
                'message' => 'Login exitoso.',
                'redirect' => $usuario['tipo_usuario'] === 'admin' ? base_url('/admin') : base_url('/')
            ]);
        } else {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Credenciales incorrectas.'
            ]);
        }
    }
    
    public function crearCuenta()
    {
        $reglas = [
            'nombre' => 'required|min_length[3]|max_length[100]',
            'email' => 'required|valid_email|is_unique[usuarios.email]',
            'password' => 'required|min_length[6]',
            'confirmar_password' => 'required|matches[password]'
        ];
        
        if (!$this->validate($reglas)) {
            return $this->response->setJSON([
                'success' => false,
                'errors' => $this->validator->getErrors()
            ]);
        }
        
        $datos = [
            'nombre' => $this->request->getPost('nombre'),
            'email' => $this->request->getPost('email'),
            'password' => $this->request->getPost('password'),
            'tipo_usuario' => 'usuario'
        ];
        
        if ($this->usuarioModel->crearUsuario($datos)) {
            return $this->response->setJSON([
                'success' => true,
                'message' => 'Cuenta creada exitosamente. Puedes iniciar sesión ahora.'
            ]);
        } else {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Error al crear la cuenta. Inténtalo nuevamente.'
            ]);
        }
    }
    
    public function logout()
    {
        session()->destroy();
        return redirect()->to('/');
    }
    
    public function perfil()
    {
        $session = session();
        
        if (!$session->get('usuario_logueado')) {
            return redirect()->to('/usuario/login');
        }
        
        $data = [
            'titulo' => 'El Faro - Mi Perfil',
            'categorias' => $this->categoriaModel->obtenerCategoriasActivas(),
            'usuario' => [
                'id' => $session->get('usuario_id'),
                'nombre' => $session->get('usuario_nombre'),
                'email' => $session->get('usuario_email'),
                'tipo' => $session->get('usuario_tipo')
            ]
        ];
        
        $data['content'] = view('usuario/perfil', $data);
return view('layout/main', $data);
    }
}