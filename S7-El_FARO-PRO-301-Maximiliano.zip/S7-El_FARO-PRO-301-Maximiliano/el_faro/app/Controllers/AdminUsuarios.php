<?php

namespace App\Controllers;

use App\Models\UsuarioModel;
use App\Models\CategoriaModel;

class AdminUsuarios extends BaseController
{
    protected $usuarioModel;
    protected $categoriaModel;
    
    public function __construct()
    {
        $this->usuarioModel = new UsuarioModel();
        $this->categoriaModel = new CategoriaModel();
    }
    
    public function index()
    {
        $session = session();
        
        if (!$session->get('usuario_logueado') || $session->get('usuario_tipo') !== 'admin') {
            return redirect()->to('/usuario/login');
        }
        
        // Obtener todos los usuarios registrados
        $usuarios = $this->usuarioModel->findAll();
        
        $data = [
            'titulo' => 'El Faro - Gestión de Usuarios',
            'categorias' => $this->categoriaModel->obtenerCategoriasActivas(),
            'usuarios' => $usuarios
        ];
        
        $data['content'] = view('admin/usuarios', $data);
        return view('layout/main', $data);
    }
    
    public function ver($id = null)
    {
        $session = session();
        
        if (!$session->get('usuario_logueado') || $session->get('usuario_tipo') !== 'admin') {
            return redirect()->to('/usuario/login');
        }
        
        if (!$id) {
            return redirect()->to('/admin/usuarios');
        }
        
        $usuario = $this->usuarioModel->find($id);
        
        if (!$usuario) {
            return redirect()->to('/admin/usuarios')->with('error', 'Usuario no encontrado.');
        }
        
        $data = [
            'titulo' => 'El Faro - Detalle Usuario',
            'categorias' => $this->categoriaModel->obtenerCategoriasActivas(),
            'usuario' => $usuario
        ];
        
        $data['content'] = view('admin/usuario_detalle', $data);
        return view('layout/main', $data);
    }
    
    public function cambiarEstado()
    {
        $session = session();
        
        if (!$session->get('usuario_logueado') || $session->get('usuario_tipo') !== 'admin') {
            return $this->response->setJSON(['success' => false, 'message' => 'No autorizado']);
        }
        
        $id = $this->request->getPost('id');
        $activo = $this->request->getPost('activo');
        
        if ($id == $session->get('usuario_id')) {
            return $this->response->setJSON(['success' => false, 'message' => 'No puedes desactivar tu propia cuenta']);
        }
        
        if ($this->usuarioModel->update($id, ['activo' => $activo])) {
            $estado = $activo ? 'activado' : 'desactivado';
            return $this->response->setJSON(['success' => true, 'message' => "Usuario $estado correctamente"]);
        } else {
            return $this->response->setJSON(['success' => false, 'message' => 'Error al cambiar el estado del usuario']);
        }
    }
    
    public function eliminar()
    {
        $session = session();
        
        if (!$session->get('usuario_logueado') || $session->get('usuario_tipo') !== 'admin') {
            return $this->response->setJSON(['success' => false, 'message' => 'No autorizado']);
        }
        
        $id = $this->request->getPost('id');
        
        if ($id == $session->get('usuario_id')) {
            return $this->response->setJSON(['success' => false, 'message' => 'No puedes eliminar tu propia cuenta']);
        }
        
        if ($this->usuarioModel->delete($id)) {
            return $this->response->setJSON(['success' => true, 'message' => 'Usuario eliminado correctamente']);
        } else {
            return $this->response->setJSON(['success' => false, 'message' => 'Error al eliminar el usuario']);
        }
    }
}