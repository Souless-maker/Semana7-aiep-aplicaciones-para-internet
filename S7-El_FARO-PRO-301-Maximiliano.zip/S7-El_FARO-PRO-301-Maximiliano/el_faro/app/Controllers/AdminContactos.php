<?php

namespace App\Controllers;

use App\Models\ContactoModel;
use App\Models\CategoriaModel;

class AdminContactos extends BaseController
{
    protected $contactoModel;
    protected $categoriaModel;
    
    public function __construct()
    {
        $this->contactoModel = new ContactoModel();
        $this->categoriaModel = new CategoriaModel();
    }
    
    public function index()
    {
        $session = session();
        
        if (!$session->get('usuario_logueado') || $session->get('usuario_tipo') !== 'admin') {
            return redirect()->to('/usuario/login');
        }
        
        // Obtener todos los mensajes de contacto
        $contactos = $this->contactoModel->orderBy('fecha_envio', 'DESC')->findAll();
        
        $data = [
            'titulo' => 'El Faro - Gestión de Mensajes',
            'categorias' => $this->categoriaModel->obtenerCategoriasActivas(),
            'contactos' => $contactos,
            'total_mensajes' => count($contactos),
            'mensajes_no_leidos' => $this->contactoModel->contarNoLeidos()
        ];
        
        $data['content'] = view('admin/contactos', $data);
        return view('layout/main', $data);
    }
    
    public function ver($id = null)
    {
        $session = session();
        
        if (!$session->get('usuario_logueado') || $session->get('usuario_tipo') !== 'admin') {
            return redirect()->to('/usuario/login');
        }
        
        if (!$id) {
            return redirect()->to('/admin/contactos');
        }
        
        $contacto = $this->contactoModel->find($id);
        
        if (!$contacto) {
            return redirect()->to('/admin/contactos')->with('error', 'Mensaje no encontrado.');
        }
        
        // Marcar como leído si no lo está
        if (!$contacto['leido']) {
            $this->contactoModel->marcarComoLeido($id);
        }
        
        $data = [
            'titulo' => 'El Faro - Ver Mensaje',
            'categorias' => $this->categoriaModel->obtenerCategoriasActivas(),
            'contacto' => $contacto
        ];
        
        $data['content'] = view('admin/contacto_detalle', $data);
        return view('layout/main', $data);
    }
    
    public function marcarLeido()
    {
        $session = session();
        
        if (!$session->get('usuario_logueado') || $session->get('usuario_tipo') !== 'admin') {
            return $this->response->setJSON(['success' => false, 'message' => 'No autorizado']);
        }
        
        $id = $this->request->getPost('id');
        
        if ($this->contactoModel->marcarComoLeido($id)) {
            return $this->response->setJSON(['success' => true, 'message' => 'Mensaje marcado como leído']);
        } else {
            return $this->response->setJSON(['success' => false, 'message' => 'Error al marcar el mensaje']);
        }
    }
    
    public function eliminar()
    {
        $session = session();
        
        if (!$session->get('usuario_logueado') || $session->get('usuario_tipo') !== 'admin') {
            return $this->response->setJSON(['success' => false, 'message' => 'No autorizado']);
        }
        
        $id = $this->request->getPost('id');
        
        if ($this->contactoModel->delete($id)) {
            return $this->response->setJSON(['success' => true, 'message' => 'Mensaje eliminado correctamente']);
        } else {
            return $this->response->setJSON(['success' => false, 'message' => 'Error al eliminar el mensaje']);
        }
    }
    
    public function responder()
    {
        $session = session();
        
        if (!$session->get('usuario_logueado') || $session->get('usuario_tipo') !== 'admin') {
            return $this->response->setJSON(['success' => false, 'message' => 'No autorizado']);
        }
        
        $id = $this->request->getPost('id');
        $respuesta = $this->request->getPost('respuesta');
        $email = $this->request->getPost('email');
        
        // Aquí se implementaría el envío de email
        // Por ahora solo marcamos como leído y retornamos éxito
        
        if ($this->contactoModel->marcarComoLeido($id)) {
            return $this->response->setJSON([
                'success' => true, 
                'message' => 'Respuesta enviada correctamente (función de email por implementar)'
            ]);
        } else {
            return $this->response->setJSON([
                'success' => false, 
                'message' => 'Error al enviar la respuesta'
            ]);
        }
    }
    
    public function marcarTodosLeidos()
    {
        $session = session();
        
        if (!$session->get('usuario_logueado') || $session->get('usuario_tipo') !== 'admin') {
            return $this->response->setJSON(['success' => false, 'message' => 'No autorizado']);
        }
        
        $db = \Config\Database::connect();
        $builder = $db->table('contactos');
        
        if ($builder->update(['leido' => 1])) {
            return $this->response->setJSON(['success' => true, 'message' => 'Todos los mensajes marcados como leídos']);
        } else {
            return $this->response->setJSON(['success' => false, 'message' => 'Error al marcar los mensajes']);
        }
    }
}