<?php

namespace App\Models;

use CodeIgniter\Model;

class ArticuloModel extends Model
{
    protected $table = 'articulos';
    protected $primaryKey = 'id';
    protected $allowedFields = ['titulo', 'contenido', 'resumen', 'imagen', 'categoria_id', 'usuario_id', 'activo', 'fecha_creacion'];
    protected $useTimestamps = false;
    
    protected $validationRules = [
        'titulo' => 'required|min_length[5]|max_length[200]',
        'contenido' => 'required|min_length[10]',
        'resumen' => 'max_length[300]',
        'categoria_id' => 'required|integer'
    ];
    
    //  MÉTODO ORIGINAL: Solo artículos PUBLICADOS (para frontend)
    public function obtenerArticulosConCategoria($limite = null, $categoriaId = null)
    {
        $builder = $this->select('articulos.*, categorias.nombre as categoria_nombre, usuarios.nombre as autor_nombre')
                       ->join('categorias', 'categorias.id = articulos.categoria_id', 'left')
                       ->join('usuarios', 'usuarios.id = articulos.usuario_id', 'left')
                       ->where('articulos.activo', 1)  // Solo publicados para frontend
                       ->orderBy('articulos.fecha_creacion', 'DESC');
        
        if ($categoriaId) {
            $builder->where('articulos.categoria_id', $categoriaId);
        }
        
        if ($limite) {
            $builder->limit($limite);
        }
        
        return $builder->get()->getResultArray();
    }
    
    //  NUEVO MÉTODO: TODOS los artículos (para admin)
    public function obtenerTodosLosArticulos($limite = null, $categoriaId = null)
    {
        $builder = $this->select('articulos.*, categorias.nombre as categoria_nombre, usuarios.nombre as autor_nombre')
                       ->join('categorias', 'categorias.id = articulos.categoria_id', 'left')
                       ->join('usuarios', 'usuarios.id = articulos.usuario_id', 'left')
                       ->orderBy('articulos.fecha_creacion', 'DESC');  // Sin filtro activo
        
        if ($categoriaId) {
            $builder->where('articulos.categoria_id', $categoriaId);
        }
        
        if ($limite) {
            $builder->limit($limite);
        }
        
        return $builder->get()->getResultArray();
    }
    
    //CORREGIDO: Usar fecha_creacion en lugar de fecha_publicacion
    public function obtenerArticuloCompleto($id)
{
    $result = $this->select('articulos.*, categorias.nombre as categoria_nombre, usuarios.nombre as autor_nombre')
                   ->join('categorias', 'categorias.id = articulos.categoria_id', 'left')
                   ->join('usuarios', 'usuarios.id = articulos.usuario_id', 'left')
                   ->where('articulos.id', $id)
                   ->where('articulos.activo', 1)
                   ->first();
    
    return $result;
}
    
    //NUEVO: Obtener artículo sin filtro activo (para editar en admin)
    public function obtenerArticuloParaAdmin($id)
    {
        $result = $this->select('articulos.*, categorias.nombre as categoria_nombre, usuarios.nombre as autor_nombre')
                       ->join('categorias', 'categorias.id = articulos.categoria_id', 'left')
                       ->join('usuarios', 'usuarios.id = articulos.usuario_id', 'left')
                       ->where('articulos.id', $id)
                       ->first();  // Sin filtro activo
        
        return $result;
    }
    
    public function obtenerArticulosRecientes($limite = 5)
    {
        return $this->obtenerArticulosConCategoria($limite);
    }
    
    public function buscarArticulos($termino)
    {
        return $this->select('articulos.*, categorias.nombre as categoria_nombre')
                   ->join('categorias', 'categorias.id = articulos.categoria_id', 'left')
                   ->where('articulos.activo', 1)  // Solo publicados en búsqueda pública
                   ->groupStart()
                       ->like('articulos.titulo', $termino)
                       ->orLike('articulos.contenido', $termino)
                       ->orLike('articulos.resumen', $termino)
                   ->groupEnd()
                   ->orderBy('articulos.fecha_creacion', 'DESC')
                   ->get()->getResultArray();
    }
    
    // NUEVO: Obtener estadísticas para dashboard admin
    public function obtenerEstadisticas()
    {
        $total = $this->countAll();
        $publicados = $this->where('activo', 1)->countAllResults(false);
        $borradores = $this->where('activo', 0)->countAllResults(false);
        $hoy = $this->where('DATE(fecha_creacion)', date('Y-m-d'))->countAllResults();
        
        return [
            'total' => $total,
            'publicados' => $publicados,
            'borradores' => $borradores,
            'hoy' => $hoy
        ];
    }
}