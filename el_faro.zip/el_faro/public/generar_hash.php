<?php
$password = 'admin123';
$hash = password_hash($password, PASSWORD_DEFAULT);

echo "Contraseña: " . $password . "<br>";
echo "Hash completo: " . $hash . "<br>";
echo "Longitud del hash: " . strlen($hash) . " caracteres<br><br>";

echo "Consulta SQL:<br>";
echo "UPDATE usuarios SET password = '" . $hash . "' WHERE email = 'admin@elfaro.cl';<br><br>";

// Verificación inmediata
if (password_verify($password, $hash)) {
    echo "Verificación OK: El hash funciona correctamente";
} else {
    echo "Error: El hash no funciona";
}
?>