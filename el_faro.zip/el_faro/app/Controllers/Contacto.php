<?php

namespace App\Controllers;

use App\Models\ContactoModel;
use App\Models\CategoriaModel;

class Contacto extends BaseController
{
    protected $contactoModel;
    protected $categoriaModel;
    
    public function __construct()
    {
        $this->contactoModel = new ContactoModel();
        $this->categoriaModel = new CategoriaModel();
    }
    
    public function index()
    {
        $data = [
            'titulo' => 'El Faro - Contacto',
            'categorias' => $this->categoriaModel->obtenerCategoriasActivas()
        ];
        
     // Asegura el contenido
    $data['content'] = view('contacto/index', $data);

    return view('layout/main', $data);
}
    
    public function enviar()
    {
        $reglas = [
            'nombre' => 'required|min_length[3]|max_length[100]',
            'email' => 'required|valid_email',
            'asunto' => 'required|min_length[5]|max_length[150]',
            'mensaje' => 'required|min_length[10]'
        ];
        
        if (!$this->validate($reglas)) {
            return $this->response->setJSON([
                'success' => false,
                'errors' => $this->validator->getErrors()
            ]);
        }
        
        $datos = [
            'nombre' => $this->request->getPost('nombre'),
            'email' => $this->request->getPost('email'),
            'asunto' => $this->request->getPost('asunto'),
            'mensaje' => $this->request->getPost('mensaje')
        ];
        
        if ($this->contactoModel->insert($datos)) {
            return $this->response->setJSON([
                'success' => true,
                'message' => 'Mensaje enviado correctamente. Te contactaremos pronto.'
            ]);
        } else {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Error al enviar el mensaje. Inténtalo nuevamente.'
            ]);
        }
    }
}