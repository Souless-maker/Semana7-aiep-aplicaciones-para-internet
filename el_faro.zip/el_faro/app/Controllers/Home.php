<?php

namespace App\Controllers;

use App\Models\ArticuloModel;
use App\Models\CategoriaModel;

class Home extends BaseController
{
    protected $articuloModel;
    protected $categoriaModel;
    
    public function __construct()
    {
        $this->articuloModel = new ArticuloModel();
        $this->categoriaModel = new CategoriaModel();
    }

    public function index()
    {
        $data = [
            'titulo' => 'El Faro - Noticias de la Comunidad',
            'articulos_destacados' => $this->articuloModel->obtenerArticulosRecientes(6),
            'categorias' => $this->categoriaModel->obtenerCategoriasActivas()
        ];

        $data['content'] = view('home/index', $data);
return view('layout/main', $data);
    }
    
    public function seccion($slug = null)
    {
        if (!$slug) {
            return redirect()->to('/');
        }
        
        $categoria = $this->categoriaModel->obtenerPorSlug($slug);
        
        if (!$categoria) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        
        $articulos = $this->articuloModel->obtenerArticulosConCategoria(null, $categoria['id']);


        
        $data = [
            'titulo' => 'El Faro - ' . $categoria['nombre'],
            'categoria' => $categoria,
            'articulos' => $articulos,
            'categorias' => $this->categoriaModel->obtenerCategoriasActivas()
        ];
        
        $data['content'] = view('home/seccion', $data);
return view('layout/main', $data);
    }
    
public function articulo($id = null)
{
    if (!$id) {
        return redirect()->to('/');
    }
    
    $articulo = $this->articuloModel->obtenerArticuloCompleto($id);
    
    if (!$articulo) {
        throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
    }
    
        
        // Obtener artículos relacionados de la misma categoría
        $articulosRelacionados = $this->articuloModel->obtenerArticulosConCategoria(4, $articulo['categoria_id']);
        
        $data = [
            'titulo' => 'El Faro - ' . $articulo['titulo'],
            'articulo' => $articulo,
            'articulos_relacionados' => array_filter($articulosRelacionados, function($item) use ($id) {
                return $item['id'] != $id;
            }),
            'categorias' => $this->categoriaModel->obtenerCategoriasActivas()
        ];
        
       $data['content'] = view('home/articulo', $data);
return view('layout/main', $data);
    }
    
    public function buscar()
    {
        $termino = $this->request->getGet('q');
        
        if (!$termino) {
            return redirect()->to('/');
        }
        
        $resultados = $this->articuloModel->buscarArticulos($termino);
        
        $data = [
            'titulo' => 'El Faro - Resultados de búsqueda: ' . $termino,
            'termino' => $termino,
            'articulos' => $resultados,
            'categorias' => $this->categoriaModel->obtenerCategoriasActivas()
        ];
        
        $data['content'] = view('home/busqueda', $data);
return view('layout/main', $data);
    }
}