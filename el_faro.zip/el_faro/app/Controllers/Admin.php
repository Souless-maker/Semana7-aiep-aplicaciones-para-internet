<?php

namespace App\Controllers;

use App\Models\ArticuloModel;
use App\Models\CategoriaModel;
use App\Models\ContactoModel;
use App\Models\UsuarioModel;

class Admin extends BaseController
{
    protected $articuloModel;
    protected $categoriaModel;
    protected $contactoModel;
    protected $usuarioModel;
    
    public function __construct()
    {
        $this->articuloModel = new ArticuloModel();
        $this->categoriaModel = new CategoriaModel();
        $this->contactoModel = new ContactoModel();
        $this->usuarioModel = new UsuarioModel();
    }
    
    public function index()
    {
        $session = session();
        
        if (!$session->get('usuario_logueado') || $session->get('usuario_tipo') !== 'admin') {
            return redirect()->to('/usuario/login');
        }
        
        $data = [
    'titulo' => 'El Faro - Panel de Administración',
    'categorias' => $this->categoriaModel->obtenerCategoriasActivas(),
    'total_articulos' => $this->articuloModel->countAll(),
    'total_categorias' => $this->categoriaModel->countAll(),
    'mensajes_sin_leer' => $this->contactoModel->contarNoLeidos(),
    'articulos_recientes' => $this->articuloModel->obtenerArticulosRecientes(5),
    'total_usuarios' => $this->usuarioModel->countAll(),
    'total_contactos' => $this->contactoModel->countAll()
];

// Solución: pasa el contenido en $data['content']
  $data['content'] = view('admin/dashboard', $data);
return view('layout/main', $data);
    }
}