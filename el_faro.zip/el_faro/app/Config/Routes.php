<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Ruta principal
$routes->get('/', 'Home::index');
$routes->get('seccion/(:segment)', 'Home::seccion/$1');
$routes->get('articulo/(:num)', 'Home::articulo/$1');
$routes->get('buscar', 'Home::buscar');

// Rutas de contacto
$routes->get('contacto', 'Contacto::index');
$routes->post('contacto/enviar', 'Contacto::enviar');

// Rutas de usuario
$routes->get('usuario/login', 'Usuario::login');
$routes->get('usuario/registro', 'Usuario::registro');
$routes->post('usuario/autenticar', 'Usuario::autenticar');
$routes->post('usuario/crearCuenta', 'Usuario::crearCuenta');
$routes->get('usuario/logout', 'Usuario::logout');
$routes->get('usuario/perfil', 'Usuario::perfil');

// Rutas de administración - Panel principal
$routes->get('admin', 'Admin::index');

// Rutas de administración - Gestión de usuarios
$routes->get('admin/usuarios', 'AdminUsuarios::index');
$routes->get('admin/usuarios/ver/(:num)', 'AdminUsuarios::ver/$1');
$routes->post('admin/usuarios/cambiarEstado', 'AdminUsuarios::cambiarEstado');
$routes->post('admin/usuarios/eliminar', 'AdminUsuarios::eliminar');
$routes->post('admin/articulos/verificarTitulo', 'AdminArticulos::verificarTitulo');


// Rutas de administración - Gestión de artículos
$routes->get('admin/articulos', 'AdminArticulos::index');
$routes->get('admin/articulos/crear', 'AdminArticulos::crear');
$routes->post('admin/articulos/guardar', 'AdminArticulos::guardar');
$routes->get('admin/articulos/editar/(:num)', 'AdminArticulos::editar/$1');
$routes->post('admin/articulos/actualizar/(:num)', 'AdminArticulos::actualizar/$1');
$routes->post('admin/articulos/eliminar', 'AdminArticulos::eliminar');
$routes->post('admin/articulos/cambiarEstado', 'AdminArticulos::cambiarEstado');

// Rutas de administración - Gestión de contactos
$routes->get('admin/contactos', 'AdminContactos::index');
$routes->get('admin/contactos/ver/(:num)', 'AdminContactos::ver/$1');
$routes->post('admin/contactos/marcarLeido', 'AdminContactos::marcarLeido');
$routes->post('admin/contactos/eliminar', 'AdminContactos::eliminar');
$routes->post('admin/contactos/responder', 'AdminContactos::responder');
$routes->post('admin/contactos/marcarTodosLeidos', 'AdminContactos::marcarTodosLeidos');
$routes->post('admin/articulos/verificarTitulo', 'AdminArticulos::verificarTitulo');