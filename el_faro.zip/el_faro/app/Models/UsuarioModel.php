<?php

namespace App\Models;

use CodeIgniter\Model;

class UsuarioModel extends Model
{
    protected $table = 'usuarios';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nombre', 'email', 'password', 'tipo_usuario', 'activo'];
    protected $useTimestamps = false;
    protected $dateFormat = 'datetime';
    
    protected $validationRules = [
        'nombre' => 'required|min_length[3]|max_length[100]',
        'email' => 'required|valid_email|is_unique[usuarios.email]',
        'password' => 'required|min_length[6]'
    ];
    
    protected $validationMessages = [
        'email' => [
            'is_unique' => 'Este email ya está registrado.'
        ]
    ];
    
    public function verificarCredenciales($email, $password)
    {
        $usuario = $this->where('email', $email)->where('activo', 1)->first();
        
        if ($usuario && password_verify($password, $usuario['password'])) {
            return $usuario;
        }
        return false;
    }
    
    public function crearUsuario($datos)
    {
        $datos['password'] = password_hash($datos['password'], PASSWORD_DEFAULT);
        return $this->insert($datos);
    }
}