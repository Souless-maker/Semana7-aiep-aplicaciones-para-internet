<?php

namespace App\Models;

use CodeIgniter\Model;

class ContactoModel extends Model
{
    protected $table = 'contactos';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nombre', 'email', 'asunto', 'mensaje', 'leido'];
    protected $useTimestamps = false;
    
    protected $validationRules = [
        'nombre' => 'required|min_length[3]|max_length[100]',
        'email' => 'required|valid_email',
        'asunto' => 'required|min_length[5]|max_length[150]',
        'mensaje' => 'required|min_length[10]'
    ];
    
    protected $validationMessages = [
        'nombre' => [
            'required' => 'El nombre es obligatorio.',
            'min_length' => 'El nombre debe tener al menos 3 caracteres.'
        ],
        'email' => [
            'required' => 'El email es obligatorio.',
            'valid_email' => 'Debe ingresar un email válido.'
        ],
        'asunto' => [
            'required' => 'El asunto es obligatorio.',
            'min_length' => 'El asunto debe tener al menos 5 caracteres.'
        ],
        'mensaje' => [
            'required' => 'El mensaje es obligatorio.',
            'min_length' => 'El mensaje debe tener al menos 10 caracteres.'
        ]
    ];
    
    public function obtenerContactosNoLeidos()
    {
        return $this->where('leido', 0)
                   ->orderBy('fecha_envio', 'DESC')
                   ->findAll();
    }
    
    public function marcarComoLeido($id)
    {
        return $this->update($id, ['leido' => 1]);
    }
    
    public function contarNoLeidos()
    {
        return $this->where('leido', 0)->countAllResults();
    }
}