<?php

namespace App\Models;

use CodeIgniter\Model;

class CategoriaModel extends Model
{
    protected $table = 'categorias';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nombre', 'descripcion', 'slug', 'activo'];
    protected $useTimestamps = false;
    
    protected $validationRules = [
        'nombre' => 'required|min_length[3]|max_length[100]',
        'slug' => 'required|is_unique[categorias.slug]'
    ];
    
    public function obtenerCategoriasActivas()
    {
        return $this->where('activo', 1)->findAll();
    }
    
    public function obtenerPorSlug($slug)
    {
        return $this->where('slug', $slug)->where('activo', 1)->first();
    }
    
    public function contarArticulos($categoriaId)
    {
        $articuloModel = new ArticuloModel();
        return $articuloModel->where('categoria_id', $categoriaId)
                           ->where('activo', 1)
                           ->countAllResults();
    }
}