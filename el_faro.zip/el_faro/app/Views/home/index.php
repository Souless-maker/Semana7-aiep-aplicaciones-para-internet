<!-- Hero Section -->
<section class="hero-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <h1 class="hero-title">El Faro</h1>
                <p class="hero-subtitle">Iluminando a la comunidad con noticias que importan</p>
                <p class="lead">Mantente informado con las últimas noticias locales, eventos comunitarios y todo lo que sucede en nuestra región.</p>
                <a href="#noticias-destacadas" class="btn btn-light btn-lg">
                    <i class="fas fa-arrow-down me-2"></i>Ver Noticias
                </a>
            </div>
            <div class="col-lg-4 text-center">
                <i class="fas fa-lighthouse fa-10x" style="opacity: 0.1;"></i>
            </div>
        </div>
    </div>
</section>

<!-- Main Content -->
<div class="container">
    <div class="row">
        <!-- Main Content Column -->
        <div class="col-lg-8">
            <section id="noticias-destacadas">
                <h2 class="section-title">Noticias Destacadas</h2>
                
                <?php if (!empty($articulos_destacados)): ?>
                    <div class="row">
                        <?php foreach ($articulos_destacados as $index => $articulo): ?>
                            <?php if ($index === 0): ?>
                                <!-- Artículo Principal -->
                                <div class="col-12 mb-4">
                                    <div class="card card-featured">
                                        <?php if (!empty($articulo['imagen'])): ?>
                                            <img src="<?= base_url('uploads/' . $articulo['imagen']) ?>" class="card-img-top" alt="<?= esc($articulo['titulo']) ?>" style="height: 300px;">
                                        <?php else: ?>
                                            <div class="card-img-top bg-light d-flex align-items-center justify-content-center" style="height: 300px;">
                                                <i class="fas fa-newspaper fa-3x text-muted"></i>
                                            </div>
                                        <?php endif; ?>
                                        <div class="card-body">
                                            <div class="article-meta">
                                                <span class="badge bg-primary me-2"><?= esc($articulo['categoria_nombre']) ?></span>
                                                <small><i class="fas fa-calendar me-1"></i><?= date('d/m/Y H:i', strtotime($articulo['fecha_publicacion'])) ?></small>
                                                <?php if (!empty($articulo['autor_nombre'])): ?>
                                                    <small class="ms-2"><i class="fas fa-user me-1"></i><?= esc($articulo['autor_nombre']) ?></small>
                                                <?php endif; ?>
                                            </div>
                                            <h3 class="card-title"><?= esc($articulo['titulo']) ?></h3>
                                            <?php if (!empty($articulo['resumen'])): ?>
                                                <p class="card-text"><?= esc($articulo['resumen']) ?></p>
                                            <?php else: ?>
                                                <p class="card-text"><?= esc(substr(strip_tags($articulo['contenido']), 0, 200)) ?>...</p>
                                            <?php endif; ?>
                                            <a href="<?= base_url('/articulo/' . $articulo['id']) ?>" class="btn btn-primary">
                                                Leer más <i class="fas fa-arrow-right ms-1"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <!-- Artículos Secundarios -->
                                <div class="col-md-6">
                                    <div class="card h-100">
                                        <?php if (!empty($articulo['imagen'])): ?>
                                            <img src="<?= base_url('uploads/' . $articulo['imagen']) ?>" class="card-img-top" alt="<?= esc($articulo['titulo']) ?>">
                                        <?php else: ?>
                                            <div class="card-img-top bg-light d-flex align-items-center justify-content-center">
                                                <i class="fas fa-newspaper fa-2x text-muted"></i>
                                            </div>
                                        <?php endif; ?>
                                        <div class="card-body d-flex flex-column">
                                            <div class="article-meta">
                                                <span class="badge bg-secondary me-2"><?= esc($articulo['categoria_nombre']) ?></span>
                                                <small><?= date('d/m/Y', strtotime($articulo['fecha_publicacion'])) ?></small>
                                            </div>
                                            <h5 class="card-title"><?= esc($articulo['titulo']) ?></h5>
                                            <?php if (!empty($articulo['resumen'])): ?>
                                                <p class="card-text"><?= esc(substr($articulo['resumen'], 0, 120)) ?>...</p>
                                            <?php else: ?>
                                                <p class="card-text"><?= esc(substr(strip_tags($articulo['contenido']), 0, 120)) ?>...</p>
                                            <?php endif; ?>
                                            <div class="mt-auto">
                                                <a href="<?= base_url('/articulo/' . $articulo['id']) ?>" class="btn btn-outline-primary btn-sm">
                                                    Leer más
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="text-center mt-4">
                        <a href="<?= base_url('/buscar') ?>" class="btn btn-outline-primary btn-lg">
                            Ver Todas las Noticias <i class="fas fa-arrow-right ms-1"></i>
                        </a>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-newspaper fa-3x text-muted mb-3"></i>
                        <h4>No hay artículos disponibles</h4>
                        <p class="text-muted">Pronto tendremos noticias frescas para ti.</p>
                    </div>
                <?php endif; ?>
            </section>
        </div>
        
        <!-- Sidebar -->
        <div class="col-lg-4">
            <!-- Categorías Widget -->
            <div class="sidebar-widget">
                <h4 class="widget-title"><i class="fas fa-list me-2"></i>Secciones</h4>
                <?php if (!empty($categorias)): ?>
                    <?php foreach ($categorias as $categoria): ?>
                        <a href="<?= base_url('/seccion/' . $categoria['slug']) ?>" class="category-link">
                            <i class="fas fa-chevron-right me-2"></i><?= esc($categoria['nombre']) ?>
                            <?php if (!empty($categoria['descripcion'])): ?>
                                <small class="d-block text-muted mt-1"><?= esc($categoria['descripcion']) ?></small>
                            <?php endif; ?>
                        </a>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <!-- Newsletter Widget -->
            <div class="sidebar-widget">
                <h4 class="widget-title"><i class="fas fa-envelope me-2"></i>Newsletter</h4>
                <p>Suscríbete para recibir las noticias más importantes en tu correo.</p>
                <form id="newsletter-form">
                    <div class="mb-3">
                        <input type="email" class="form-control" placeholder="Tu email" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-paper-plane me-1"></i>Suscribirse
                    </button>
                </form>
            </div>
            
            <!-- Información de Contacto Widget -->
            <div class="sidebar-widget">
                <h4 class="widget-title"><i class="fas fa-info-circle me-2"></i>Contáctanos</h4>
                <div class="contact-info">
                    <p><i class="fas fa-envelope me-2 text-primary"></i>info@elfaro.cl</p>
                    <p><i class="fas fa-phone me-2 text-primary"></i>+56 2 1234 5678</p>
                    <p><i class="fas fa-map-marker-alt me-2 text-primary"></i>Calama, Antofagasta, Chile</p>
                </div>
                <a href="<?= base_url('/contacto') ?>" class="btn btn-outline-primary w-100">
                    Enviar Mensaje
                </a>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Newsletter form
    $('#newsletter-form').on('submit', function(e) {
        e.preventDefault();
        const email = $(this).find('input[type="email"]').val();
        
        // Aquí podrías implementar la lógica de suscripción
        alert('¡Gracias por suscribirte! Te mantendremos informado.');
        $(this)[0].reset();
    });
});
</script>