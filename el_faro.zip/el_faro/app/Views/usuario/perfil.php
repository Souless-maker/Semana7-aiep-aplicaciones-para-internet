<!-- Breadcrumb -->
<div class="container mt-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('/') ?>">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Mi Perfil</li>
        </ol>
    </nav>
</div>

<!-- User Profile -->
<div class="container">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <!-- Profile Header -->
            <div class="card mb-4">
                <div class="card-body">
                    <div class="text-center mb-4">
                        <div class="bg-primary text-white rounded-circle d-inline-flex align-items-center justify-content-center" style="width: 80px; height: 80px;">
                            <i class="fas fa-user fa-2x"></i>
                        </div>
                        <h2 class="mt-3"><?= esc($usuario['nombre']) ?></h2>
                        <p class="text-muted"><?= esc($usuario['email']) ?></p>
                        <span class="badge bg-<?= $usuario['tipo'] === 'admin' ? 'danger' : 'primary' ?>">
                            <?= $usuario['tipo'] === 'admin' ? 'Administrador' : 'Usuario' ?>
                        </span>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <h5>Información Personal</h5>
                            <table class="table">
                                <tr>
                                    <td><strong>Nombre:</strong></td>
                                    <td><?= esc($usuario['nombre']) ?></td>
                                </tr>
                                <tr>
                                    <td><strong>Email:</strong></td>
                                    <td><?= esc($usuario['email']) ?></td>
                                </tr>
                                <tr>
                                    <td><strong>Tipo de cuenta:</strong></td>
                                    <td>
                                        <span class="badge bg-<?= $usuario['tipo'] === 'admin' ? 'danger' : 'primary' ?>">
                                            <?= $usuario['tipo'] === 'admin' ? 'Administrador' : 'Usuario' ?>
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <td><strong>Miembro desde:</strong></td>
                                    <td>
                                        <i class="fas fa-calendar me-1"></i>
                                        Enero 2025
                                    </td>
                                </tr>
                            </table>
                        </div>
                        
                        <div class="col-md-6">
                            <h5>Acciones Rápidas</h5>
                            <div class="d-grid gap-2">
                                <?php if ($usuario['tipo'] === 'admin'): ?>
                                    <a href="<?= base_url('/admin') ?>" class="btn btn-danger">
                                        <i class="fas fa-cog me-2"></i>Panel de Administración
                                    </a>
                                <?php endif; ?>
                                
                                <button class="btn btn-outline-primary" onclick="editProfile()">
                                    <i class="fas fa-edit me-2"></i>Editar Perfil
                                </button>
                                
                                <a href="<?= base_url('/contacto') ?>" class="btn btn-outline-primary">
                                    <i class="fas fa-envelope me-2"></i>Contactar Redacción
                                </a>
                                
                                <a href="<?= base_url('/usuario/logout') ?>" class="btn btn-outline-danger">
                                    <i class="fas fa-sign-out-alt me-2"></i>Cerrar Sesión
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Profile Stats -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-chart-bar me-2"></i>Estadísticas de Actividad</h5>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-md-3">
                            <div class="stat-item">
                                <h3 class="text-primary">24</h3>
                                <small class="text-muted">Artículos Leídos</small>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="stat-item">
                                <h3 class="text-success">8</h3>
                                <small class="text-muted">Artículos Guardados</small>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="stat-item">
                                <h3 class="text-info">12</h3>
                                <small class="text-muted">Comentarios</small>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="stat-item">
                                <h3 class="text-warning">5</h3>
                                <small class="text-muted">Artículos Compartidos</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Preferences -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-cog me-2"></i>Preferencias</h5>
                </div>
                <div class="card-body">
                    <form id="preferences-form">
                        <div class="row">
                            <div class="col-md-6">
                                <h6>Notificaciones por Email</h6>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" id="newsletter" checked>
                                    <label class="form-check-label" for="newsletter">
                                        Newsletter semanal
                                    </label>
                                </div>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" id="breaking-news" checked>
                                    <label class="form-check-label" for="breaking-news">
                                        Noticias urgentes
                                    </label>
                                </div>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" id="comments-replies">
                                    <label class="form-check-label" for="comments-replies">
                                        Respuestas a comentarios
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <h6>Categorías de Interés</h6>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" id="cat-deportes" checked>
                                    <label class="form-check-label" for="cat-deportes">
                                        Deportes
                                    </label>
                                </div>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" id="cat-cultura" checked>
                                    <label class="form-check-label" for="cat-cultura">
                                        Cultura
                                    </label>
                                </div>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" id="cat-economia">
                                    <label class="form-check-label" for="cat-economia">
                                        Economía
                                    </label>
                                </div>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" id="cat-tecnologia">
                                    <label class="form-check-label" for="cat-tecnologia">
                                        Tecnología
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="mt-3">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>Guardar Preferencias
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Saved Articles -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-bookmark me-2"></i>Artículos Guardados</h5>
                </div>
                <div class="card-body">
                    <!-- Sample saved articles -->
                    <div class="saved-article mb-3">
                        <div class="d-flex">
                            <div class="flex-grow-1">
                                <h6><a href="#" class="text-decoration-none">Inauguración del nuevo centro comunitario</a></h6>
                                <small class="text-muted">
                                    <span class="badge bg-secondary me-2">Noticias Locales</span>
                                    Guardado hace 2 días
                                </small>
                            </div>
                            <button class="btn btn-outline-danger btn-sm">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div class="saved-article mb-3">
                        <div class="d-flex">
                            <div class="flex-grow-1">
                                <h6><a href="#" class="text-decoration-none">Festival de música folclórica</a></h6>
                                <small class="text-muted">
                                    <span class="badge bg-secondary me-2">Cultura</span>
                                    Guardado hace 5 días
                                </small>
                            </div>
                            <button class="btn btn-outline-danger btn-sm">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div class="text-center">
                        <a href="#" class="btn btn-outline-primary">Ver todos los artículos guardados</a>
                    </div>
                </div>
            </div>
            
            <!-- Recent Activity -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-history me-2"></i>Actividad Reciente</h5>
                </div>
                <div class="card-body">
                    <div class="timeline">
                        <div class="timeline-item mb-3">
                            <div class="d-flex">
                                <div class="timeline-marker bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 30px; height: 30px;">
                                    <i class="fas fa-eye fa-sm"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <small class="text-muted">Hace 1 hora</small>
                                    <p class="mb-0">Leíste el artículo "Torneo de fútbol amateur 2025"</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="timeline-item mb-3">
                            <div class="d-flex">
                                <div class="timeline-marker bg-success text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 30px; height: 30px;">
                                    <i class="fas fa-bookmark fa-sm"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <small class="text-muted">Hace 2 días</small>
                                    <p class="mb-0">Guardaste "Inauguración del nuevo centro comunitario"</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="timeline-item mb-3">
                            <div class="d-flex">
                                <div class="timeline-marker bg-info text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 30px; height: 30px;">
                                    <i class="fas fa-comment fa-sm"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <small class="text-muted">Hace 3 días</small>
                                    <p class="mb-0">Comentaste en "Nuevas inversiones impulsan el comercio local"</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="text-center">
                        <button class="btn btn-outline-primary btn-sm">Ver toda la actividad</button>
                    </div>
                </div>
            </div>
            
            <!-- Security Settings -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-shield-alt me-2"></i>Seguridad</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6>Cambiar Contraseña</h6>
                            <p class="small text-muted">Última actualización: Nunca</p>
                            <button class="btn btn-outline-warning" onclick="changePassword()">
                                <i class="fas fa-key me-2"></i>Cambiar Contraseña
                            </button>
                        </div>
                        <div class="col-md-6">
                            <h6>Sesiones Activas</h6>
                            <p class="small text-muted">Dispositivos con sesión iniciada: 1</p>
                            <button class="btn btn-outline-danger" onclick="logoutAllDevices()">
                                <i class="fas fa-sign-out-alt me-2"></i>Cerrar Todas las Sesiones
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Account Actions -->
            <?php if ($usuario['tipo'] === 'admin'): ?>
                <div class="card mt-4">
                    <div class="card-body">
                        <h5 class="card-title">Acceso Rápido - Panel Admin</h5>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="text-center p-3">
                                    <i class="fas fa-newspaper fa-2x text-primary mb-2"></i>
                                    <h6>Gestionar Artículos</h6>
                                    <a href="<?= base_url('/admin/articulos') ?>" class="btn btn-sm btn-outline-primary">Ir</a>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="text-center p-3">
                                    <i class="fas fa-tags fa-2x text-success mb-2"></i>
                                    <h6>Categorías</h6>
                                    <a href="<?= base_url('/admin/categorias') ?>" class="btn btn-sm btn-outline-success">Ir</a>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="text-center p-3">
                                    <i class="fas fa-envelope fa-2x text-warning mb-2"></i>
                                    <h6>Mensajes</h6>
                                    <a href="<?= base_url('/admin/contactos') ?>" class="btn btn-sm btn-outline-warning">Ir</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Edit Profile Modal -->
<div class="modal fade" id="editProfileModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Editar Perfil</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="edit-profile-form">
                    <div class="mb-3">
                        <label for="edit-nombre" class="form-label">Nombre</label>
                        <input type="text" class="form-control" id="edit-nombre" value="<?= esc($usuario['nombre']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit-email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="edit-email" value="<?= esc($usuario['email']) ?>" required>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary" onclick="saveProfile()">Guardar Cambios</button>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Preferences form
    $('#preferences-form').on('submit', function(e) {
        e.preventDefault();
        alert('Preferencias guardadas correctamente.');
    });
});

function editProfile() {
    $('#editProfileModal').modal('show');
}

function saveProfile() {
    alert('Perfil actualizado correctamente (función por implementar)');
    $('#editProfileModal').modal('hide');
}

function changePassword() {
    alert('Funcionalidad de cambio de contraseña por implementar');
}

function logoutAllDevices() {
    if (confirm('¿Estás seguro de que quieres cerrar sesión en todos los dispositivos?')) {
        alert('Sesiones cerradas en todos los dispositivos (función por implementar)');
    }
}
</script>