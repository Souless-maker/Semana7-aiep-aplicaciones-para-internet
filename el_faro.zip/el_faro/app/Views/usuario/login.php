<!-- Breadcrumb -->
<div class="container mt-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('/') ?>">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Iniciar Sesión</li>
        </ol>
    </nav>
</div>

<!-- Login Form -->
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">
            <div class="card">
                <div class="card-body p-5">
                    <div class="text-center mb-4">
                        <i class="fas fa-sign-in-alt fa-3x text-primary mb-3"></i>
                        <h2>Iniciar Sesión</h2>
                        <p class="text-muted">Accede a tu cuenta de El Faro</p>
                    </div>
                    
                    <?php if (session()->getFlashdata('error')): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <?= session()->getFlashdata('error') ?>
                        </div>
                    <?php endif; ?>
                    
                    <div id="mensaje-login" style="display: none;"></div>
                    
                    <form id="login-form">
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                <input type="email" class="form-control" id="email" name="email" placeholder="tu@email.com" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="password" class="form-label">Contraseña</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                <input type="password" class="form-control" id="password" name="password" placeholder="Tu contraseña" required>
                                <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="recordar">
                            <label class="form-check-label" for="recordar">
                                Recordar sesión
                            </label>
                        </div>
                        
                        <button type="submit" class="btn btn-primary btn-lg w-100 mb-3">
                            <i class="fas fa-sign-in-alt me-2"></i>Iniciar Sesión
                        </button>
                    </form>
                    
                    <div class="text-center">
                        <p class="mb-2">
                            <a href="#" class="text-primary">¿Olvidaste tu contraseña?</a>
                        </p>
                        <p class="mb-0">¿No tienes cuenta? 
                            <a href="<?= base_url('/usuario/registro') ?>" class="text-primary">Regístrate aquí</a>
                        </p>
                    </div>
                </div>
            </div>
            
            <!-- Demo Credentials Card -->
            <div class="card mt-3">
                <div class="card-body">
                    <h6 class="card-title"><i class="fas fa-info-circle me-2"></i>Credenciales de Demostración</h6>
                    <p class="card-text small">Para probar el sistema puedes usar:</p>
                    <div class="row">
                        <div class="col-6">
                            <strong>Admin:</strong><br>
                            <small>admin@elfaro.cl</small><br>
                            <small>admin123</small>
                        </div>
                        <div class="col-6">
                            <button class="btn btn-outline-primary btn-sm" onclick="fillDemoCredentials()">
                                <i class="fas fa-fill me-1"></i>Usar Demo
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Función que espera a que jQuery esté disponible
function waitForjQuery(callback) {
    if (typeof jQuery !== 'undefined') {
        callback();
    } else {
        setTimeout(function() {
            waitForjQuery(callback);
        }, 50);
    }
}

// Ejecutar cuando jQuery esté listo
waitForjQuery(function() {
    $(document).ready(function() {
        // Toggle password visibility
        $('#togglePassword').on('click', function() {
            const passwordField = $('#password');
            const passwordFieldType = passwordField.attr('type');
            const toggleIcon = $(this).find('i');
            
            if (passwordFieldType === 'password') {
                passwordField.attr('type', 'text');
                toggleIcon.removeClass('fa-eye').addClass('fa-eye-slash');
            } else {
                passwordField.attr('type', 'password');
                toggleIcon.removeClass('fa-eye-slash').addClass('fa-eye');
            }
        });
        
        // Login form submission
        $('#login-form').on('submit', function(e) {
            e.preventDefault();
            
            const $form = $(this);
            const $btn = $form.find('button[type="submit"]');
            const $resultado = $('#mensaje-login');
            
            $btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Iniciando sesión...');
            
            $.ajax({
                url: '<?= base_url('/usuario/autenticar') ?>',
                type: 'POST',
                data: $form.serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        $resultado.html(`
                            <div class="alert alert-success">
                                <i class="fas fa-check-circle me-2"></i>
                                ${response.message}
                            </div>
                        `).show();
                        
                        setTimeout(function() {
                            window.location.href = response.redirect || '<?= base_url('/') ?>';
                        }, 1500);
                    } else {
                        $resultado.html(`
                            <div class="alert alert-danger">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                ${response.message}
                            </div>
                        `).show();
                    }
                },
                error: function() {
                    $resultado.html(`
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            Error de conexión. Inténtalo nuevamente.
                        </div>
                    `).show();
                },
                complete: function() {
                    $btn.prop('disabled', false).html('<i class="fas fa-sign-in-alt me-2"></i>Iniciar Sesión');
                }
            });
        });
    });
});

// Fill demo credentials - esta función no necesita jQuery
function fillDemoCredentials() {
    // Esperar a jQuery para esta función también
    waitForjQuery(function() {
        $('#email').val('admin@elfaro.cl');
        $('#password').val('admin123');
    });
}
</script>