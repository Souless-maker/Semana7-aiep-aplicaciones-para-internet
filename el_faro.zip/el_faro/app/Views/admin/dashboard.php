<!-- Breadcrumb -->
<div class="container mt-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('/') ?>">Inicio</a></li>
            <li class="breadcrumb-item active" aria-current="page">Panel de Administración</li>
        </ol>
    </nav>
</div>

<!-- Admin Dashboard -->
<div class="container">
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1><i class="fas fa-tachometer-alt me-2"></i>Panel de Administración</h1>
                    <p class="lead">Gestiona el contenido de El Faro desde este panel.</p>
                </div>
                <div>
                    <span class="badge bg-success">En línea</span>
                    <small class="text-muted d-block">Último acceso: <?= date('d/m/Y H:i') ?></small>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Stats Cards -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card text-white bg-primary">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?= $total_articulos ?></h4>
                            <p class="mb-0">Artículos</p>
                        </div>
                        <i class="fas fa-newspaper fa-2x"></i>
                    </div>
                    <div class="progress mt-2" style="height: 4px;">
                        <div class="progress-bar bg-light" style="width: 85%"></div>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="<?= base_url('/admin/articulos') ?>" class="text-white text-decoration-none">
                        Ver todos <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card text-white bg-success">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?= $total_categorias ?></h4>
                            <p class="mb-0">Categorías</p>
                        </div>
                        <i class="fas fa-tags fa-2x"></i>
                    </div>
                    <div class="progress mt-2" style="height: 4px;">
                        <div class="progress-bar bg-light" style="width: 60%"></div>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="<?= base_url('/admin/categorias') ?>" class="text-white text-decoration-none">
                        Gestionar <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card text-white bg-warning">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?= $mensajes_sin_leer ?></h4>
                            <p class="mb-0">Mensajes sin leer</p>
                        </div>
                        <i class="fas fa-envelope fa-2x"></i>
                    </div>
                    <div class="progress mt-2" style="height: 4px;">
                        <div class="progress-bar bg-light" style="width: 30%"></div>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="<?= base_url('/admin/contactos') ?>" class="text-white text-decoration-none">
                        Ver mensajes <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card text-white bg-info">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4>1.2K</h4>
                            <p class="mb-0">Visitas hoy</p>
                        </div>
                        <i class="fas fa-eye fa-2x"></i>
                    </div>
                    <div class="progress mt-2" style="height: 4px;">
                        <div class="progress-bar bg-light" style="width: 70%"></div>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="<?= base_url('/') ?>" class="text-white text-decoration-none">
                        Ver sitio <i class="fas fa-external-link-alt"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Quick Actions -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-bolt me-2"></i>Acciones Rápidas</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3">
                            <button class="btn btn-primary btn-lg w-100 mb-3" onclick="createArticle()">
                                <i class="fas fa-plus-circle me-2"></i>Nuevo Artículo
                            </button>
                        </div>
                        <div class="col-md-3">
                            <button class="btn btn-success btn-lg w-100 mb-3" onclick="createCategory()">
                                <i class="fas fa-plus me-2"></i>Nueva Categoría
                            </button>
                        </div>
                        <div class="col-md-3">
                            <a href="<?= base_url('/admin/contactos') ?>" class="btn btn-warning btn-lg w-100 mb-3">
                                <i class="fas fa-inbox me-2"></i>Ver Mensajes
                            </a>
                        </div>
                        <div class="col-md-3">
                            <button class="btn btn-info btn-lg w-100 mb-3" onclick="generateReport()">
                                <i class="fas fa-chart-line me-2"></i>Generar Reporte
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <!-- Recent Articles -->
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="fas fa-clock me-2"></i>Artículos Recientes</h5>
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-primary active" data-filter="all">Todos</button>
                        <button class="btn btn-outline-primary" data-filter="published">Publicados</button>
                        <button class="btn btn-outline-primary" data-filter="draft">Borradores</button>
                    </div>
                </div>
                <div class="card-body">
                    <?php if (!empty($articulos_recientes)): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Título</th>
                                        <th>Categoría</th>
                                        <th>Autor</th>
                                        <th>Fecha</th>
                                        <th>Estado</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($articulos_recientes as $articulo): ?>
                                        <tr>
                                            <td>
                                                <strong><?= esc($articulo['titulo']) ?></strong><br>
                                                <small class="text-muted"><?= esc(substr(strip_tags($articulo['contenido']), 0, 60)) ?>...</small>
                                            </td>
                                            <td>
                                                <span class="badge bg-secondary"><?= esc($articulo['categoria_nombre']) ?></span>
                                            </td>
                                            <td><?= esc($articulo['autor_nombre']) ?></td>
                                            <td>
                                                <small><?= date('d/m/Y H:i', strtotime($articulo['fecha_publicacion'])) ?></small>
                                            </td>
                                            <td>
                                                <span class="badge bg-success">Publicado</span>
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <a href="<?= base_url('/articulo/' . $articulo['id']) ?>" class="btn btn-outline-primary" target="_blank" title="Ver">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <button class="btn btn-outline-warning" onclick="editArticle(<?= $articulo['id'] ?>)" title="Editar">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <button class="btn btn-outline-danger" onclick="deleteArticle(<?= $articulo['id'] ?>)" title="Eliminar">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="text-center">
                            <a href="<?= base_url('/admin/articulos') ?>" class="btn btn-outline-primary">
                                Ver todos los artículos
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fas fa-newspaper fa-3x text-muted mb-3"></i>
                            <h5>No hay artículos recientes</h5>
                            <p class="text-muted">Comienza creando tu primer artículo.</p>
                            <button class="btn btn-primary" onclick="createArticle()">
                                <i class="fas fa-plus me-2"></i>Crear Artículo
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Sidebar -->
        <div class="col-lg-4">
            <!-- System Status -->
            <div class="card mb-4">
                <div class="card-header">
                    <h6 class="mb-0"><i class="fas fa-server me-2"></i>Estado del Sistema</h6>
                </div>
                <div class="card-body">
                    <div class="status-item d-flex justify-content-between mb-2">
                        <span>Base de datos:</span>
                        <span class="badge bg-success">Conectada</span>
                    </div>
                    <div class="status-item d-flex justify-content-between mb-2">
                        <span>Servidor web:</span>
                        <span class="badge bg-success">Funcionando</span>
                    </div>
                    <div class="status-item d-flex justify-content-between mb-2">
                        <span>Espacio en disco:</span>
                        <span class="badge bg-warning">85%</span>
                    </div>
                    <div class="status-item d-flex justify-content-between">
                        <span>Última copia:</span>
                        <span class="text-muted small">Ayer</span>
                    </div>
                </div>
            </div>
            
            <!-- Quick Stats -->
            <div class="card mb-4">
                <div class="card-header">
                    <h6 class="mb-0"><i class="fas fa-chart-pie me-2"></i>Estadísticas Rápidas</h6>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <div class="d-flex justify-content-between">
                            <span>Artículos publicados:</span>
                            <strong><?= $total_articulos ?></strong>
                        </div>
                        <div class="progress mt-1" style="height: 6px;">
                            <div class="progress-bar bg-primary" style="width: 80%"></div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="d-flex justify-content-between">
                            <span>Mensajes pendientes:</span>
                            <strong class="text-warning"><?= $mensajes_sin_leer ?></strong>
                        </div>
                        <div class="progress mt-1" style="height: 6px;">
                            <div class="progress-bar bg-warning" style="width: 30%"></div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="d-flex justify-content-between">
                            <span>Visitas hoy:</span>
                            <strong class="text-info">1,234</strong>
                        </div>
                        <div class="progress mt-1" style="height: 6px;">
                            <div class="progress-bar bg-info" style="width: 65%"></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Recent Activity -->
            <div class="card mb-4">
                <div class="card-header">
                    <h6 class="mb-0"><i class="fas fa-history me-2"></i>Actividad Reciente</h6>
                </div>
                <div class="card-body">
                    <div class="activity-item mb-3">
                        <div class="d-flex">
                            <div class="activity-icon bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 24px; height: 24px;">
                                <i class="fas fa-plus fa-xs"></i>
                            </div>
                            <div class="flex-grow-1">
                                <small class="text-muted">Hace 2 horas</small>
                                <p class="mb-0 small">Nuevo artículo publicado</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="activity-item mb-3">
                        <div class="d-flex">
                            <div class="activity-icon bg-success text-white rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 24px; height: 24px;">
                                <i class="fas fa-edit fa-xs"></i>
                            </div>
                            <div class="flex-grow-1">
                                <small class="text-muted">Hace 4 horas</small>
                                <p class="mb-0 small">Categoría actualizada</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="activity-item mb-3">
                        <div class="d-flex">
                            <div class="activity-icon bg-warning text-white rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 24px; height: 24px;">
                                <i class="fas fa-envelope fa-xs"></i>
                            </div>
                            <div class="flex-grow-1">
                                <small class="text-muted">Hace 6 horas</small>
                                <p class="mb-0 small">Nuevo mensaje recibido</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Tools -->
            <div class="card">
                <div class="card-header">
                    <h6 class="mb-0"><i class="fas fa-tools me-2"></i>Herramientas</h6>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <button class="btn btn-outline-primary btn-sm" onclick="backupDatabase()">
                            <i class="fas fa-database me-2"></i>Backup BD
                        </button>
                        <button class="btn btn-outline-info btn-sm" onclick="clearCache()">
                            <i class="fas fa-broom me-2"></i>Limpiar Caché
                        </button>
                        <button class="btn btn-outline-success btn-sm" onclick="exportData()">
                            <i class="fas fa-download me-2"></i>Exportar Datos
                        </button>
                        <button class="btn btn-outline-warning btn-sm" onclick="viewLogs()">
                            <i class="fas fa-file-alt me-2"></i>Ver Logs
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Create Article Modal -->
<div class="modal fade" id="createArticleModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Crear Nuevo Artículo</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="create-article-form">
                    <div class="mb-3">
                        <label for="titulo" class="form-label">Título</label>
                        <input type="text" class="form-control" id="titulo" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="categoria" class="form-label">Categoría</label>
                                <select class="form-select" id="categoria" required>
                                    <option value="">Seleccionar...</option>
                                    <option value="1">Noticias Locales</option>
                                    <option value="2">Deportes</option>
                                    <option value="3">Cultura</option>
                                    <option value="4">Economía</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="estado" class="form-label">Estado</label>
                                <select class="form-select" id="estado">
                                    <option value="borrador">Borrador</option>
                                    <option value="publicado">Publicar</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="resumen" class="form-label">Resumen</label>
                        <textarea class="form-control" id="resumen" rows="2"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="contenido" class="form-label">Contenido</label>
                        <textarea class="form-control" id="contenido" rows="6" required></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary" onclick="saveArticle()">Guardar Artículo</button>
            </div>
        </div>
    </div>
</div>

<<script>
$(document).ready(function() {
    // Filter buttons
    $('[data-filter]').on('click', function() {
        $('[data-filter]').removeClass('active');
        $(this).addClass('active');
        // Aquí se implementaría el filtrado real
    });
});

// Quick Actions
function createArticle() {
    window.location.href = '<?= base_url('/admin/articulos/crear') ?>';
}

function createCategory() {
    alert('Funcionalidad de crear categoría por implementar');
}

function generateReport() {
    alert('Generando reporte... (función por implementar)');
}

function saveArticle() {
    alert('Artículo guardado correctamente (función por implementar)');
    $('#createArticleModal').modal('hide');
}

// Article Actions - CORREGIDAS
function editArticle(id) {
    if (id && !isNaN(id)) {
        window.location.href = '<?= base_url('/admin/articulos/editar/') ?>' + id;
    } else {
        console.error('ID inválido:', id);
    }
}

function deleteArticle(id) {
    if (confirm('¿Estás seguro de que quieres eliminar este artículo?')) {
        $.ajax({
            url: '<?= base_url('/admin/articulos/eliminar') ?>',
            type: 'POST',
            data: { id: id },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    alert('Artículo eliminado correctamente');
                    location.reload();
                } else {
                    alert('Error: ' + response.message);
                }
            },
            error: function() {
                alert('Error de conexión');
            }
        });
    }
}

// Tools
function backupDatabase() {
    if (confirm('¿Realizar backup de la base de datos?')) {
        alert('Backup iniciado (función por implementar)');
    }
}

function clearCache() {
    alert('Caché limpiado correctamente');
}

function exportData() {
    alert('Exportando datos... (función por implementar)');
}

function viewLogs() {
    alert('Visualización de logs por implementar');
}
</script>