<!-- Breadcrumb -->
<div class="container mt-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('/') ?>">Inicio</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('/admin') ?>">Panel Admin</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('/admin/articulos') ?>">Artículos</a></li>
            <li class="breadcrumb-item active" aria-current="page">Crear Artículo</li>
        </ol>
    </nav>
</div>

<!-- Header -->
<div class="container">
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1><i class="fas fa-plus-circle me-2"></i>Crear Nuevo Artículo</h1>
                    <p class="lead">Redacta un nuevo artículo para El Faro</p>
                </div>
                <div>
                    <a href="<?= base_url('/admin/articulos') ?>" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-left me-2"></i>Volver a Artículos
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Form -->
<div class="container">
    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-edit me-2"></i>Información del Artículo</h5>
                </div>
                <div class="card-body">
                    <div id="mensaje-crear" style="display: none;"></div>
                    
                    <form id="crear-articulo-form" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="titulo" class="form-label">Título del Artículo *</label>
                            <input type="text" class="form-control" id="titulo" name="titulo" placeholder="Ingresa un título atractivo..." required>
                            <small class="text-muted">Mínimo 5 caracteres, máximo 200</small>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="categoria_id" class="form-label">Categoría *</label>
                                    <select class="form-select" id="categoria_id" name="categoria_id" required>
                                        <option value="">Seleccionar categoría...</option>
                                        <?php if (!empty($categoriasSelect)): ?>
                                            <?php foreach ($categoriasSelect as $categoria): ?>
                                                <option value="<?= $categoria['id'] ?>"><?= esc($categoria['nombre']) ?></option>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="imagen" class="form-label">Imagen del Artículo</label>
                                    <input type="file" class="form-control" id="imagen" name="imagen" accept="image/*">
                                    <small class="text-muted">Formatos: JPG, PNG, GIF. Máximo 2MB</small>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="resumen" class="form-label">Resumen/Entradilla</label>
                            <textarea class="form-control" id="resumen" name="resumen" rows="3" placeholder="Breve resumen del artículo que aparecerá en las listas..."></textarea>
                            <small class="text-muted">Máximo 300 caracteres. Este texto aparecerá en la página principal.</small>
                        </div>
                        
                        <div class="mb-3">
                            <label for="contenido" class="form-label">Contenido del Artículo *</label>
                            <textarea class="form-control" id="contenido" name="contenido" rows="12" placeholder="Escribe aquí el contenido completo del artículo..." required></textarea>
                            <small class="text-muted">Contenido principal del artículo. Mínimo 10 caracteres.</small>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" id="activo" name="activo" checked>
                                        <label class="form-check-label" for="activo">
                                            <strong>Publicar inmediatamente</strong>
                                        </label>
                                    </div>
                                    <small class="text-muted">Si no está marcado, se guardará como borrador</small>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Autor</label>
                                    <input type="text" class="form-control" value="<?= esc(session()->get('usuario_nombre')) ?>" disabled>
                                    <small class="text-muted">Automáticamente asignado al usuario actual</small>
                                </div>
                            </div>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <a href="<?= base_url('/admin/articulos') ?>" class="btn btn-secondary me-md-2">
                                <i class="fas fa-times me-2"></i>Cancelar
                            </a>
                            <button type="button" class="btn btn-outline-primary me-md-2" onclick="guardarBorrador()">
                                <i class="fas fa-save me-2"></i>Guardar Borrador
                            </button>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-paper-plane me-2"></i>Crear y Publicar
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Sidebar -->
        <div class="col-lg-4">
            <!-- Preview Card -->
            <div class="card mb-4">
                <div class="card-header">
                    <h6 class="mb-0"><i class="fas fa-eye me-2"></i>Vista Previa</h6>
                </div>
                <div class="card-body">
                    <div id="preview-imagen" class="mb-3" style="display: none;">
                        <img id="preview-img" src="" class="img-fluid rounded" alt="Preview">
                    </div>
                    <h6 id="preview-titulo" class="text-muted">El título aparecerá aquí...</h6>
                    <p id="preview-resumen" class="small text-muted">El resumen aparecerá aquí...</p>
                    <small class="text-muted">
                        <i class="fas fa-calendar me-1"></i>
                        <span id="preview-fecha"><?= date('d/m/Y H:i') ?></span>
                    </small>
                </div>
            </div>
            
            <!-- Writing Tips -->
            <div class="card mb-4">
                <div class="card-header">
                    <h6 class="mb-0"><i class="fas fa-lightbulb me-2"></i>Consejos de Redacción</h6>
                </div>
                <div class="card-body">
                    <ul class="list-unstyled mb-0">
                        <li class="mb-2">
                            <i class="fas fa-check text-success me-2"></i>
                            <strong>Título:</strong> Claro y atractivo
                        </li>
                        <li class="mb-2">
                            <i class="fas fa-check text-success me-2"></i>
                            <strong>Resumen:</strong> Resume la noticia en 2-3 líneas
                        </li>
                        <li class="mb-2">
                            <i class="fas fa-check text-success me-2"></i>
                            <strong>Contenido:</strong> Información completa y verificada
                        </li>
                        <li class="mb-0">
                            <i class="fas fa-check text-success me-2"></i>
                            <strong>Imagen:</strong> Relacionada con el contenido
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- Categories Info -->
            <div class="card">
                <div class="card-header">
                    <h6 class="mb-0"><i class="fas fa-tags me-2"></i>Categorías Disponibles</h6>
                </div>
                <div class="card-body">
                    <?php if (!empty($categoriasSelect)): ?>
                        <?php foreach ($categoriasSelect as $categoria): ?>
                            <span class="badge bg-secondary me-1 mb-1"><?= esc($categoria['nombre']) ?></span>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    <hr>
                    <small class="text-muted">
                        Selecciona la categoría que mejor describa tu artículo para facilitar la navegación de los lectores.
                    </small>
                </div>
            </div>
        </div>
    </div>
</div>

<script>

$(document).ready(function() {
    // Contador de caracteres para resumen
    $('#resumen').on('input', function() {
        const length = $(this).val().length;
        const maxLength = 300;
        const remaining = maxLength - length;
        
        $(this).next('.text-muted').text(remaining + ' caracteres restantes (máximo 300)');
        
        if (remaining < 50) {
            $(this).next('.text-muted').addClass('text-warning');
        } else {
            $(this).next('.text-muted').removeClass('text-warning');
        }
    });
    
    // Vista previa - Título
    $('#titulo').on('input', function() {
        const titulo = $(this).val() || 'El título aparecerá aquí...';
        $('#preview-titulo').text(titulo);
    });

    // Validación de título único (tiempo real)
    let tituloTimeout;
    $('#titulo').on('blur', function() {
        const titulo = $(this).val().trim();
        
        if (titulo.length > 5) {
            clearTimeout(tituloTimeout);
            
            tituloTimeout = setTimeout(function() {
                $.ajax({
                    url: '<?= base_url('/admin/articulos/verificarTitulo') ?>',
                    type: 'POST',
                    data: { 
                        titulo: titulo,
                        '<?= csrf_token() ?>': '<?= csrf_hash() ?>'
                    },
                    dataType: 'json',
                    success: function(response) {
                        // Limpiar mensajes anteriores
                        $('#titulo').next('.invalid-feedback').remove();
                        
                        if (response.existe) {
                            $('#titulo').addClass('is-invalid');
                            $('#titulo').after('<div class="invalid-feedback">Ya existe un artículo con este título</div>');
                        } else {
                            $('#titulo').removeClass('is-invalid');
                        }
                    },
                    error: function() {
                        console.log('Error verificando título único');
                    }
                });
            }, 500);
        }
    });
    
    // Vista previa - Resumen
    $('#resumen').on('input', function() {
        const resumen = $(this).val() || 'El resumen aparecerá aquí...';
        $('#preview-resumen').text(resumen);
    });
    
    // Vista previa de imagen
    $('#imagen').on('change', function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                $('#preview-img').attr('src', e.target.result);
                $('#preview-imagen').show();
            };
            reader.readAsDataURL(file);
        } else {
            $('#preview-imagen').hide();
        }
    });
    
    // Envío de formulario
    $('#crear-articulo-form').on('submit', function(e) {
        e.preventDefault();
        
        const form = $(this);
        const btn = form.find('button[type="submit"]');
        const resultado = $('#mensaje-crear');
        
        btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Creando artículo...');
        
        // FormData para archivos
        const formData = new FormData(this);
        
        $.ajax({
            url: '<?= base_url('/admin/articulos/guardar') ?>',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    resultado.html(
                        '<div class="alert alert-success">' +
                        '<i class="fas fa-check-circle me-2"></i>' +
                        response.message +
                        '</div>'
                    ).show();
                    
                    // Limpiar draft guardado
                    localStorage.removeItem('articulo_draft');
                    
                    setTimeout(function() {
                        if (response.articulo_id) {
                            window.location.href = '<?= base_url('/articulo/') ?>' + response.articulo_id;
                        } else {
                            window.location.href = '<?= base_url('/admin/articulos') ?>';
                        }
                    }, 1500);
                } else {
                    let errorHtml = '<div class="alert alert-danger">';
                    errorHtml += '<i class="fas fa-exclamation-triangle me-2"></i>';
                    
                    if (response.errors) {
                        errorHtml += '<ul class="mb-0">';
                        for (const field in response.errors) {
                            errorHtml += '<li>' + response.errors[field] + '</li>';
                        }
                        errorHtml += '</ul>';
                    } else {
                        errorHtml += response.message;
                    }
                    
                    errorHtml += '</div>';
                    resultado.html(errorHtml).show();
                }
            },
            error: function() {
                resultado.html(
                    '<div class="alert alert-danger">' +
                    '<i class="fas fa-exclamation-triangle me-2"></i>' +
                    'Error de conexión. Inténtalo nuevamente.' +
                    '</div>'
                ).show();
            },
            complete: function() {
                btn.prop('disabled', false).html('<i class="fas fa-paper-plane me-2"></i>Crear y Publicar');
            }
        });
    });
    
    // Cargar borrador guardado
    const draft = localStorage.getItem('articulo_draft');
    if (draft) {
        try {
            const data = JSON.parse(draft);
            if (confirm('Se encontró un borrador previo. ¿Deseas cargar el contenido guardado?')) {
                $('#titulo').val(data.titulo).trigger('input');
                $('#resumen').val(data.resumen).trigger('input');
                $('#contenido').val(data.contenido);
                $('#categoria_id').val(data.categoria_id);
            }
        } catch (e) {
            console.error('Error cargando borrador:', e);
        }
    }
    
    // Auto-guardado cada 5 segundos
    let autoSaveTimeout;
    function autoSave() {
        clearTimeout(autoSaveTimeout);
        autoSaveTimeout = setTimeout(function() {
            const formData = {
                titulo: $('#titulo').val(),
                resumen: $('#resumen').val(),
                contenido: $('#contenido').val(),
                categoria_id: $('#categoria_id').val()
            };
            localStorage.setItem('articulo_draft', JSON.stringify(formData));
            console.log('Borrador auto-guardado');
        }, 5000);
    }
    
    $('#titulo, #resumen, #contenido').on('input', autoSave);
});

// Guardar como borrador
function guardarBorrador() {
    $('#activo').prop('checked', false);
    $('#crear-articulo-form').trigger('submit');
}
</script>