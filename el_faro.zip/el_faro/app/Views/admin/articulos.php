
<!-- Breadcrumb -->
<div class="container mt-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('/') ?>">Inicio</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('/admin') ?>">Panel Admin</a></li>
            <li class="breadcrumb-item active" aria-current="page">Gestión de Artículos</li>
        </ol>
    </nav>
</div>

<!-- Header -->
<div class="container">
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1><i class="fas fa-newspaper me-2"></i>Gestión de Artículos</h1>
                    <p class="lead">Administra el contenido editorial de El Faro</p>
                </div>
                <div>
                    <a href="<?= base_url('/admin') ?>" class="btn btn-outline-secondary me-2">
                        <i class="fas fa-arrow-left me-2"></i>Volver al Panel
                    </a>
                    <a href="<?= base_url('/admin/articulos/crear') ?>" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i>Nuevo Artículo
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Alerts -->
<div class="container">
    <div id="mensaje-articulos" style="display: none;"></div>
    
    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i>
            <?= session()->getFlashdata('success') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if (session()->getFlashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <?= session()->getFlashdata('error') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
</div>

<!-- Statistics Cards -->
<div class="container">
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card text-white bg-primary">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?= count($articulos) ?></h4>
                            <p class="mb-0">Total Artículos</p>
                        </div>
                        <i class="fas fa-newspaper fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-success">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?= count(array_filter($articulos, function($a) { return $a['activo'] == 1; })) ?></h4>
                            <p class="mb-0">Publicados</p>
                        </div>
                        <i class="fas fa-check-circle fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-warning">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?= count(array_filter($articulos, function($a) { return $a['activo'] == 0; })) ?></h4>
                            <p class="mb-0">Borradores</p>
                        </div>
                        <i class="fas fa-edit fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-info">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?= count(array_filter($articulos, function($a) { return date('Y-m-d', strtotime($a['fecha_creacion'])) == date('Y-m-d'); })) ?></h4>
                            <p class="mb-0">Hoy</p>
                        </div>
                        <i class="fas fa-calendar fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Articles Table -->
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="fas fa-list me-2"></i>Listado de Artículos
                        </h5>
                        <div class="d-flex gap-2">
                            <!-- Search Box -->
                            <div class="input-group" style="width: 250px;">
                                <input type="text" class="form-control" id="buscar-articulo" placeholder="Buscar artículo...">
                                <button class="btn btn-outline-secondary" type="button">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                            
                            <!-- Filter Dropdown -->
                            <div class="dropdown">
                                <button class="btn btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" id="filter-button">
                                    <i class="fas fa-filter me-1"></i>Filtrar
                                </button>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="#" data-filter="todos">📄 Todos los artículos</a></li>
                                    <li><a class="dropdown-item" href="#" data-filter="publicados">✅ Solo publicados</a></li>
                                    <li><a class="dropdown-item" href="#" data-filter="borradores">📝 Solo borradores</a></li>
                                    <li><a class="dropdown-item" href="#" data-filter="hoy">📅 Creados hoy</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item text-primary" href="#" onclick="resetFilters()">🔄 Restaurar vista completa</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?php if (!empty($articulos)): ?>
                        <div class="table-responsive">
                            <table class="table table-hover" id="tabla-articulos">
                                <thead class="table-light">
                                    <tr>
                                        <th>Título</th>
                                        <th>Categoría</th>
                                        <th>Autor</th>
                                        <th>Fecha</th>
                                        <th>Estado</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($articulos as $articulo): ?>
                                        <tr data-activo="<?= $articulo['activo'] ?>" data-fecha="<?= date('Y-m-d', strtotime($articulo['fecha_creacion'])) ?>">
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <?php if (!empty($articulo['imagen'])): ?>
                                                        <img src="<?= base_url('uploads/' . $articulo['imagen']) ?>" class="me-2 rounded" style="width: 40px; height: 40px; object-fit: cover;" alt="Imagen">
                                                    <?php else: ?>
                                                        <div class="bg-light d-flex align-items-center justify-content-center me-2 rounded" style="width: 40px; height: 40px;">
                                                            <i class="fas fa-newspaper text-muted"></i>
                                                        </div>
                                                    <?php endif; ?>
                                                    <div>
                                                        <strong><?= esc($articulo['titulo']) ?></strong>
                                                        <?php if (!empty($articulo['resumen'])): ?>
                                                            <br><small class="text-muted"><?= esc(substr($articulo['resumen'], 0, 60)) ?>...</small>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <span class="badge bg-secondary"><?= esc($articulo['categoria_nombre'] ?? 'Sin categoría') ?></span>
                                            </td>
                                            <td>
                                                <?= esc($articulo['autor_nombre'] ?? 'Sin autor') ?>
                                            </td>
                                            <td>
                                                <small>
                                                    <?= date('d/m/Y H:i', strtotime($articulo['fecha_creacion'])) ?>
                                                </small>
                                            </td>
                                            <td>
                                                <span class="badge bg-<?= $articulo['activo'] ? 'success' : 'warning' ?>">
                                                    <?= $articulo['activo'] ? 'Publicado' : 'Borrador' ?>
                                                </span>
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <a href="<?= base_url('/articulo/' . $articulo['id']) ?>" class="btn btn-outline-info" target="_blank" title="Ver artículo">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    
                                                    <a href="<?= base_url('/admin/articulos/editar/' . $articulo['id']) ?>" class="btn btn-outline-primary" title="Editar">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    
                                                    <button class="btn btn-outline-warning" onclick="cambiarEstado(<?= $articulo['id'] ?>, <?= $articulo['activo'] ? 0 : 1 ?>)" title="<?= $articulo['activo'] ? 'Despublicar' : 'Publicar' ?>">
                                                        <i class="fas fa-<?= $articulo['activo'] ? 'eye-slash' : 'eye' ?>"></i>
                                                    </button>
                                                    
                                                    <button class="btn btn-outline-danger" onclick="eliminarArticulo(<?= $articulo['id'] ?>)" title="Eliminar">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!-- Pagination -->
                        <div class="mt-3">
                            <small class="text-muted">
                                Mostrando <?= count($articulos) ?> artículo(s)
                            </small>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-newspaper fa-4x text-muted mb-3"></i>
                            <h5>No hay artículos</h5>
                            <p class="text-muted">Comienza creando tu primer artículo de noticias.</p>
                            <a href="<?= base_url('/admin/articulos/crear') ?>" class="btn btn-primary">
                                <i class="fas fa-plus me-2"></i>Crear Primer Artículo
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Stats -->
<div class="container mt-3">
    <div class="card">
        <div class="card-header">
            <h6 class="mb-0"><i class="fas fa-chart-bar me-2"></i>Estadísticas Rápidas</h6>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-3">
                    <p class="small">Artículos este mes: <strong><?= count(array_filter($articulos, function($a) { return date('Y-m', strtotime($a['fecha_creacion'])) == date('Y-m'); })) ?></strong></p>
                </div>
                <div class="col-md-3">
                    <p class="small">Promedio por día: <strong><?= round(count($articulos) / max(1, (time() - strtotime('2025-01-01')) / 86400), 1) ?></strong></p>
                </div>
                <div class="col-md-3">
                    <p class="small">Categoría más usada: <strong>Noticias Locales</strong></p>
                </div>
                <div class="col-md-3">
                    <div class="text-end">
                        <button class="btn btn-outline-success btn-sm" onclick="exportarArticulos()">
                            <i class="fas fa-download me-1"></i>Exportar Lista
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirmar Eliminación</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>¿Estás seguro de que quieres eliminar este artículo?</p>
                <p><strong>Esta acción no se puede deshacer.</strong></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-danger" id="confirmar-eliminar">Eliminar Artículo</button>
            </div>
        </div>
    </div>
</div>

<script>

$(document).ready(function() {
    console.log('Inicializando gestión de artículos...');
    
    // BÚSQUEDA
    $('#buscar-articulo').on('keyup', function() {
        const searchTerm = $(this).val().toLowerCase();
        let visibleCount = 0;
        
        $('#tabla-articulos tbody tr').each(function() {
            const text = $(this).text().toLowerCase();
            const visible = text.includes(searchTerm);
            $(this).toggle(visible);
            if (visible) visibleCount++;
        });
        
        console.log('Búsqueda: "' + searchTerm + '" - ' + visibleCount + ' resultados');
    });
    
    // FILTROS
    $('[data-filter]').on('click', function(e) {
        e.preventDefault();
        const filter = $(this).data('filter');
        const today = new Date().toISOString().split('T')[0];
        
        console.log('Aplicando filtro: ' + filter);
        
        // PRIMERO: Mostrar todas las filas
        $('#tabla-articulos tbody tr').show();
        
        let visibleCount = 0;
        
        // SEGUNDO: Aplicar filtro específico
        if (filter !== 'todos') {
            $('#tabla-articulos tbody tr').each(function() {
                const activo = parseInt($(this).data('activo'));
                const fecha = $(this).data('fecha');
                let show = true;
                
                switch(filter) {
                    case 'publicados':
                        show = activo === 1;
                        break;
                    case 'borradores':
                        show = activo === 0;
                        break;
                    case 'hoy':
                        show = fecha === today;
                        break;
                }
                
                if (show) {
                    $(this).show();
                    visibleCount++;
                } else {
                    $(this).hide();
                }
            });
        } else {
            visibleCount = $('#tabla-articulos tbody tr').length;
        }
        
        // Actualizar texto del botón
        const filterText = $(this).text();
        $('#filter-button').html('<i class="fas fa-filter me-1"></i>' + filterText);
        
        console.log('Filtro aplicado: ' + visibleCount + ' artículos visibles');
    });
});

// FUNCIÓN RESET FILTERS
function resetFilters() {
    console.log('Reseteando filtros...');
    $('#tabla-articulos tbody tr').show();
    $('#buscar-articulo').val('');
    $('#filter-button').html('<i class="fas fa-filter me-1"></i>Filtrar');
    console.log('Filtros reseteados');
}

// CAMBIAR ESTADO
function cambiarEstado(id, activo) {
    const accion = activo ? 'publicar' : 'despublicar';
    
    if (confirm('¿Seguro que quieres ' + accion + ' este artículo?')) {
        console.log('Cambiando estado del artículo ' + id + ' a ' + activo);
        
        $.ajax({
            url: '<?= base_url('/admin/articulos/cambiarEstado') ?>',
            type: 'POST',
            data: { 
                id: id, 
                activo: activo,
                '<?= csrf_token() ?>': '<?= csrf_hash() ?>'
            },
            dataType: 'json',
            success: function(response) {
                console.log('Respuesta cambio estado:', response);
                
                if (response.success) {
                    $('#mensaje-articulos').html(
                        '<div class="alert alert-success alert-dismissible fade show">' +
                        '<i class="fas fa-check-circle me-2"></i>' +
                        response.message +
                        '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>' +
                        '</div>'
                    ).show();
                    
                    setTimeout(function() { location.reload(); }, 1000);
                } else {
                    $('#mensaje-articulos').html(
                        '<div class="alert alert-danger alert-dismissible fade show">' +
                        '<i class="fas fa-exclamation-triangle me-2"></i>' +
                        response.message +
                        '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>' +
                        '</div>'
                    ).show();
                }
            },
            error: function(xhr, status, error) {
                console.error('Error AJAX cambio estado:', error);
                $('#mensaje-articulos').html(
                    '<div class="alert alert-danger alert-dismissible fade show">' +
                    '<i class="fas fa-exclamation-triangle me-2"></i>' +
                    'Error de conexión. Inténtalo nuevamente.' +
                    '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>' +
                    '</div>'
                ).show();
            }
        });
    }
}

// ELIMINAR ARTÍCULO
let articuloAEliminar = null;

function eliminarArticulo(id) {
    console.log('Preparando eliminación del artículo ' + id);
    articuloAEliminar = id;
    $('#deleteModal').modal('show');
}

$('#confirmar-eliminar').on('click', function() {
    if (articuloAEliminar) {
        console.log('Eliminando artículo ' + articuloAEliminar);
        
        $.ajax({
            url: '<?= base_url('/admin/articulos/eliminar') ?>',
            type: 'POST',
            data: { 
                id: articuloAEliminar,
                '<?= csrf_token() ?>': '<?= csrf_hash() ?>'
            },
            dataType: 'json',
            success: function(response) {
                console.log('Respuesta eliminación:', response);
                $('#deleteModal').modal('hide');
                
                if (response.success) {
                    $('#mensaje-articulos').html(
                        '<div class="alert alert-success alert-dismissible fade show">' +
                        '<i class="fas fa-check-circle me-2"></i>' +
                        response.message +
                        '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>' +
                        '</div>'
                    ).show();
                    
                    setTimeout(function() { location.reload(); }, 1000);
                } else {
                    $('#mensaje-articulos').html(
                        '<div class="alert alert-danger alert-dismissible fade show">' +
                        '<i class="fas fa-exclamation-triangle me-2"></i>' +
                        response.message +
                        '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>' +
                        '</div>'
                    ).show();
                }
            },
            error: function(xhr, status, error) {
                console.error('Error AJAX eliminación:', error);
                $('#deleteModal').modal('hide');
                $('#mensaje-articulos').html(
                    '<div class="alert alert-danger alert-dismissible fade show">' +
                    '<i class="fas fa-exclamation-triangle me-2"></i>' +
                    'Error de conexión. Inténtalo nuevamente.' +
                    '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>' +
                    '</div>'
                ).show();
            }
        });
    }
});

// EXPORTAR
function exportarArticulos() {
    alert('Exportando lista de artículos... (función por implementar)');
}
</script>