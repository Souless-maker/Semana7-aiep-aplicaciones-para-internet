<!-- Breadcrumb -->
<div class="container mt-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('/') ?>">Inicio</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('/admin') ?>">Panel Admin</a></li>
            <li class="breadcrumb-item active" aria-current="page">Mensajes de Contacto</li>
        </ol>
    </nav>
</div>

<!-- Header -->
<div class="container">
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1><i class="fas fa-envelope me-2"></i>Mensajes de Contacto</h1>
                    <p class="lead">Gestiona los mensajes enviados desde el formulario de contacto</p>
                </div>
                <div>
                    <a href="<?= base_url('/admin') ?>" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-left me-2"></i>Volver al Panel
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Alerts -->
<div class="container">
    <div id="mensaje-contactos" style="display: none;"></div>
    
    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i>
            <?= session()->getFlashdata('success') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if (session()->getFlashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <?= session()->getFlashdata('error') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
</div>

<!-- Statistics Cards -->
<div class="container">
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card text-white bg-primary">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?= $total_mensajes ?></h4>
                            <p class="mb-0">Total Mensajes</p>
                        </div>
                        <i class="fas fa-envelope fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-warning">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?= $mensajes_no_leidos ?></h4>
                            <p class="mb-0">Sin Leer</p>
                        </div>
                        <i class="fas fa-envelope-open fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-success">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?= $total_mensajes - $mensajes_no_leidos ?></h4>
                            <p class="mb-0">Leídos</p>
                        </div>
                        <i class="fas fa-check-circle fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-info">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4><?= date('j') ?></h4>
                            <p class="mb-0">Hoy</p>
                        </div>
                        <i class="fas fa-calendar fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Messages Table -->
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="fas fa-inbox me-2"></i>Bandeja de Mensajes
                        </h5>
                        <div class="d-flex gap-2">
                            <!-- Quick Actions -->
                            <?php if ($mensajes_no_leidos > 0): ?>
                                <button class="btn btn-success btn-sm" onclick="marcarTodosLeidos()">
                                    <i class="fas fa-check-double me-1"></i>Marcar todos como leídos
                                </button>
                            <?php endif; ?>
                            
                            <!-- Search Box -->
                            <div class="input-group" style="width: 250px;">
                                <input type="text" class="form-control form-control-sm" id="buscar-mensaje" placeholder="Buscar mensaje...">
                                <button class="btn btn-outline-secondary btn-sm" type="button">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                            
                            <!-- Filter -->
                            <div class="dropdown">
                                <button class="btn btn-outline-primary btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                    <i class="fas fa-filter me-1"></i>Filtrar
                                </button>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="#" data-filter="todos">Todos los mensajes</a></li>
                                    <li><a class="dropdown-item" href="#" data-filter="no-leidos">Sin leer</a></li>
                                    <li><a class="dropdown-item" href="#" data-filter="leidos">Leídos</a></li>
                                    <li><a class="dropdown-item" href="#" data-filter="hoy">De hoy</a></li>
                                    <li><a class="dropdown-item" href="#" data-filter="semana">Esta semana</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?php if (!empty($contactos)): ?>
                        <div class="table-responsive">
                            <table class="table table-hover" id="tabla-mensajes">
                                <thead class="table-light">
                                    <tr>
                                        <th width="50">Estado</th>
                                        <th>Nombre</th>
                                        <th>Email</th>
                                        <th>Asunto</th>
                                        <th>Fecha</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($contactos as $contacto): ?>
                                        <tr class="<?= !$contacto['leido'] ? 'table-warning' : '' ?>" 
                                            data-leido="<?= $contacto['leido'] ?>" 
                                            data-fecha="<?= date('Y-m-d', strtotime($contacto['fecha_envio'])) ?>">
                                            <td>
                                                <?php if (!$contacto['leido']): ?>
                                                    <span class="badge bg-warning" title="Sin leer">
                                                        <i class="fas fa-envelope"></i>
                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge bg-success" title="Leído">
                                                        <i class="fas fa-check"></i>
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <strong><?= esc($contacto['nombre']) ?></strong>
                                                <?php if (!$contacto['leido']): ?>
                                                    <small class="badge bg-danger ms-1">Nuevo</small>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="mailto:<?= esc($contacto['email']) ?>" class="text-decoration-none">
                                                    <?= esc($contacto['email']) ?>
                                                </a>
                                            </td>
                                            <td>
                                                <div class="text-truncate" style="max-width: 200px;" title="<?= esc($contacto['asunto']) ?>">
                                                    <?= esc($contacto['asunto']) ?>
                                                </div>
                                                <small class="text-muted">
                                                    <?= esc(substr($contacto['mensaje'], 0, 50)) ?>...
                                                </small>
                                            </td>
                                            <td>
                                                <small>
                                                    <?= date('d/m/Y H:i', strtotime($contacto['fecha_envio'])) ?>
                                                </small>
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <a href="<?= base_url('/admin/contactos/ver/' . $contacto['id']) ?>" class="btn btn-outline-primary" title="Ver mensaje completo">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    
                                                    <?php if (!$contacto['leido']): ?>
                                                        <button class="btn btn-outline-success" onclick="marcarLeido(<?= $contacto['id'] ?>)" title="Marcar como leído">
                                                            <i class="fas fa-check"></i>
                                                        </button>
                                                    <?php endif; ?>
                                                    
                                                    <button class="btn btn-outline-info" onclick="responderMensaje(<?= $contacto['id'] ?>, '<?= esc($contacto['email']) ?>')" title="Responder">
                                                        <i class="fas fa-reply"></i>
                                                    </button>
                                                    
                                                    <button class="btn btn-outline-danger" onclick="eliminarMensaje(<?= $contacto['id'] ?>)" title="Eliminar">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!-- Pagination -->
                        <div class="mt-3">
                            <small class="text-muted">
                                Mostrando <?= count($contactos) ?> mensaje(s)
                            </small>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-inbox fa-4x text-muted mb-3"></i>
                            <h5>No hay mensajes</h5>
                            <p class="text-muted">Los mensajes enviados desde el formulario de contacto aparecerán aquí.</p>
                            <a href="<?= base_url('/contacto') ?>" class="btn btn-outline-primary">
                                <i class="fas fa-external-link-alt me-2"></i>Ver formulario de contacto
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Response Modal -->
<div class="modal fade" id="responderModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Responder Mensaje</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="responder-form">
                    <input type="hidden" id="mensaje-id" name="id">
                    <div class="mb-3">
                        <label for="respuesta-email" class="form-label">Email de destino</label>
                        <input type="email" class="form-control" id="respuesta-email" name="email" readonly>
                    </div>
                    <div class="mb-3">
                        <label for="respuesta-asunto" class="form-label">Asunto</label>
                        <input type="text" class="form-control" id="respuesta-asunto" name="asunto" value="Re: ">
                    </div>
                    <div class="mb-3">
                        <label for="respuesta-mensaje" class="form-label">Mensaje</label>
                        <textarea class="form-control" id="respuesta-mensaje" name="respuesta" rows="6" placeholder="Escribe tu respuesta aquí..."></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary" onclick="enviarRespuesta()">
                    <i class="fas fa-paper-plane me-2"></i>Enviar Respuesta
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirmar Eliminación</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>¿Estás seguro de que quieres eliminar este mensaje?</p>
                <p><strong>Esta acción no se puede deshacer.</strong></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-danger" id="confirmar-eliminar">Eliminar Mensaje</button>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Search functionality
    $('#buscar-mensaje').on('keyup', function() {
        const searchTerm = $(this).val().toLowerCase();
        $('#tabla-mensajes tbody tr').each(function() {
            const text = $(this).text().toLowerCase();
            $(this).toggle(text.includes(searchTerm));
        });
    });
    
    // Filter functionality
    $('[data-filter]').on('click', function(e) {
        e.preventDefault();
        const filter = $(this).data('filter');
        const today = new Date().toISOString().split('T')[0];
        const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
        
        $('#tabla-mensajes tbody tr').each(function() {
            const leido = $(this).data('leido');
            const fecha = $(this).data('fecha');
            let show = true;
            
            switch(filter) {
                case 'no-leidos':
                    show = leido == 0;
                    break;
                case 'leidos':
                    show = leido == 1;
                    break;
                case 'hoy':
                    show = fecha === today;
                    break;
                case 'semana':
                    show = fecha >= oneWeekAgo;
                    break;
                default:
                    show = true;
            }
            
            $(this).toggle(show);
        });
    });
});

// Mark as read
function marcarLeido(id) {
    $.ajax({
        url: '<?= base_url('/admin/contactos/marcarLeido') ?>',
        type: 'POST',
        data: { id: id },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                location.reload();
            } else {
                alert('Error: ' + response.message);
            }
        }
    });
}

// Mark all as read
function marcarTodosLeidos() {
    if (confirm('¿Marcar todos los mensajes como leídos?')) {
        $.ajax({
            url: '<?= base_url('/admin/contactos/marcarTodosLeidos') ?>',
            type: 'POST',
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    $('#mensaje-contactos').html(`
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="fas fa-check-circle me-2"></i>
                            ${response.message}
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    `).show();
                    
                    setTimeout(() => location.reload(), 1000);
                } else {
                    alert('Error: ' + response.message);
                }
            }
        });
    }
}

// Reply to message
function responderMensaje(id, email) {
    $('#mensaje-id').val(id);
    $('#respuesta-email').val(email);
    $('#responderModal').modal('show');
}

function enviarRespuesta() {
    const form = $('#responder-form');
    const data = form.serialize();
    
    $.ajax({
        url: '<?= base_url('/admin/contactos/responder') ?>',
        type: 'POST',
        data: data,
        dataType: 'json',
        success: function(response) {
            $('#responderModal').modal('hide');
            
            if (response.success) {
                $('#mensaje-contactos').html(`
                    <div class="alert alert-success alert-dismissible fade show">
                        <i class="fas fa-check-circle me-2"></i>
                        ${response.message}
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                `).show();
                
                setTimeout(() => location.reload(), 1000);
            } else {
                alert('Error: ' + response.message);
            }
        }
    });
}

// Delete message
let mensajeAEliminar = null;

function eliminarMensaje(id) {
    mensajeAEliminar = id;
    $('#deleteModal').modal('show');
}

$('#confirmar-eliminar').on('click', function() {
    if (mensajeAEliminar) {
        $.ajax({
            url: '<?= base_url('/admin/contactos/eliminar') ?>',
            type: 'POST',
            data: { id: mensajeAEliminar },
            dataType: 'json',
            success: function(response) {
                $('#deleteModal').modal('hide');
                
                if (response.success) {
                    $('#mensaje-contactos').html(`
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="fas fa-check-circle me-2"></i>
                            ${response.message}
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    `).show();
                    
                    setTimeout(() => location.reload(), 1000);
                } else {
                    alert('Error: ' + response.message);
                }
            }
        });
    }
});
</script>